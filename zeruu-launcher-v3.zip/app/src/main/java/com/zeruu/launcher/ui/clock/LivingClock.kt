package com.zeruu.launcher.ui.clock

import android.text.format.DateFormat
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.zeruu.launcher.data.ZeruuSettings
import kotlinx.coroutines.delay
import java.time.LocalDateTime

/** Waktu sekarang, diperbarui tepat di pergantian menit. */
@Composable
fun rememberNow(): State<LocalDateTime> = produceState(initialValue = LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(60_000L - (System.currentTimeMillis() % 60_000L))
    }
}

private fun fontFor(style: Int): Pair<FontFamily, FontWeight> = when (style) {
    1 -> FontFamily.SansSerif to FontWeight.Bold
    2 -> FontFamily.Serif to FontWeight.Normal
    else -> FontFamily.SansSerif to FontWeight.Light
}

/**
 * Jam Zeruu. Dipakai bersama oleh lock screen, widget home, dan overlay morph,
 * sehingga tampilannya selalu identik di ketiga tempat.
 */
@Composable
fun LivingClockText(
    settings: ZeruuSettings,
    sizeSp: Float,
    now: LocalDateTime,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val systemIs24 = remember { DateFormat.is24HourFormat(context) }
    val use24 = when (settings.clockFormat) {
        1 -> false
        2 -> true
        else -> systemIs24
    }
    val hour = if (use24) now.hour else (now.hour % 12).let { if (it == 0) 12 else it }
    val hh = if (use24) "%02d".format(hour) else hour.toString()
    val mm = "%02d".format(now.minute)
    val text = when {
        settings.clockStacked -> "$hh\n$mm"
        settings.clockColon -> "$hh:$mm"
        else -> "$hh $mm"
    }
    val (family, weight) = fontFor(settings.clockStyle)
    val glow: Shadow? = if (settings.clockGlow) {
        Shadow(Color(settings.accent).copy(alpha = 0.7f), Offset.Zero, sizeSp * 0.4f)
    } else null

    Box(modifier) {
        Text(
            text = text,
            color = Color(settings.clockColor).copy(alpha = 0.94f),
            fontSize = sizeSp.sp,
            fontFamily = family,
            fontWeight = weight,
            letterSpacing = (-sizeSp * 0.01f).sp,
            lineHeight = if (settings.clockStacked) (sizeSp * 0.95f).sp else TextUnit.Unspecified,
            textAlign = TextAlign.Center,
            style = TextStyle(shadow = glow)
        )
    }
}
