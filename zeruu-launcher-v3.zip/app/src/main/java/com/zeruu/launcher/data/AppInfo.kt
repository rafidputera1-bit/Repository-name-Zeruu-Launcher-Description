package com.zeruu.launcher.data

import android.content.ComponentName
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap

@Immutable
data class AppInfo(
    val label: String,
    val componentName: ComponentName,
    val icon: ImageBitmap
) {
    val packageName: String get() = componentName.packageName
    val key: String get() = componentName.flattenToString()
}
