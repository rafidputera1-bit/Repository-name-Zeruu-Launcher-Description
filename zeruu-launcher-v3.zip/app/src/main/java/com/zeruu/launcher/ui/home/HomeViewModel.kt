package com.zeruu.launcher.ui.home

import android.app.Application
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.net.Uri
import android.os.UserHandle
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zeruu.launcher.data.AppInfo
import com.zeruu.launcher.data.AppRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class HomeUiState(
    val apps: List<AppInfo> = emptyList(),
    val dock: List<AppInfo> = emptyList()
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()
    private var loadJob: Job? = null

    private val packageCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String, user: UserHandle) = refresh()
        override fun onPackageAdded(packageName: String, user: UserHandle) = refresh()
        override fun onPackageChanged(packageName: String, user: UserHandle) = refresh()
        override fun onPackagesAvailable(
            packageNames: Array<out String>, user: UserHandle, replacing: Boolean
        ) = refresh()

        override fun onPackagesUnavailable(
            packageNames: Array<out String>, user: UserHandle, replacing: Boolean
        ) = refresh()
    }

    init {
        repository.registerCallback(packageCallback)
        refresh()
    }

    fun refresh() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            val apps = repository.loadApps()
            val dock = defaultDockPackages()
                .mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg } }
                .ifEmpty { apps.take(DOCK_SIZE) }
                .take(DOCK_SIZE)
            _state.value = HomeUiState(apps = apps, dock = dock)
        }
    }

    fun launch(app: AppInfo) = repository.launch(app)

    /** Dock sementara: aplikasi default telepon, pesan, browser, dan kamera. Dock kustom hadir di Tahap 2. */
    private fun defaultDockPackages(): List<String> {
        val pm = getApplication<Application>().packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents
            .mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .filter { it != "android" }
            .distinct()
    }

    override fun onCleared() {
        repository.unregisterCallback(packageCallback)
        super.onCleared()
    }

    private companion object {
        const val DOCK_SIZE = 4
    }
}
