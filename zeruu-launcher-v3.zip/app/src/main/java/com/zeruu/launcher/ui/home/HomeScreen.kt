package com.zeruu.launcher.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeruu.launcher.data.AppInfo
import com.zeruu.launcher.data.ZeruuSettings
import com.zeruu.launcher.ui.clock.LivingClockText
import com.zeruu.launcher.ui.clock.rememberNow
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.min

private fun easeOutBack(t: Float, overshoot: Float): Float {
    val c3 = overshoot + 1f
    val x = t - 1f
    return 1f + c3 * x * x * x + overshoot * x * x
}

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    settings: ZeruuSettings,
    progress: () -> Float,
    clockHidden: Boolean,
    onClockBounds: (Rect) -> Unit,
    onLongPress: () -> Unit,
    onDoubleTap: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val now by rememberNow()

    // Launcher tidak boleh keluar saat tombol kembali ditekan.
    BackHandler(enabled = true) { }

    val dockApps = remember(state, settings.dockCount) {
        (state.dock + state.apps.filter { a -> state.dock.none { it.key == a.key } })
            .take(settings.dockCount)
    }
    val cols = settings.gridColumns
    val clockTop = settings.lockY < 0.5f
    val a = settings.scrim

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { onDoubleTap() },
                    onLongPress = { onLongPress() }
                )
            }
    ) {
        // Redup wallpaper, muncul bertahap saat lock terbuka.
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = ((progress() - 0.1f) / 0.6f).coerceIn(0f, 1f) }
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = (a * 1.3f).coerceIn(0f, 1f)),
                            Color.Black.copy(alpha = (a * 0.4f).coerceIn(0f, 1f)),
                            Color.Black.copy(alpha = (a * 1.8f).coerceIn(0f, 1f))
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .graphicsLayer {
                    val t = ((progress() - 0.12f) / 0.6f).coerceIn(0f, 1f)
                    alpha = t
                    val sc = 0.95f + 0.05f * t
                    scaleX = sc
                    scaleY = sc
                }
        ) {
            HomeClockWidget(
                settings = settings,
                now = now,
                hidden = clockHidden,
                progress = progress,
                onBounds = onClockBounds,
                modifier = Modifier.padding(top = 56.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 24.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                itemsIndexed(state.apps, key = { _, app -> app.key }) { index, app ->
                    val row = index / cols
                    // Ikon masuk berkelompok per baris; arah dan urutan mengikuti posisi jam.
                    val enter = Modifier.graphicsLayer {
                        if (!settings.staggerIcons) return@graphicsLayer
                        val p = progress()
                        if (p >= 1f) return@graphicsLayer
                        val order = if (clockTop) min(row, 7) else 7 - min(row, 7)
                        val raw = ((p - 0.2f - order * 0.045f) / 0.5f).coerceIn(0f, 1f)
                        val e = easeOutBack(raw, 0.6f + settings.animBounce * 1.6f)
                        alpha = (raw * 1.8f).coerceIn(0f, 1f)
                        val sc = 0.55f + 0.45f * e
                        scaleX = sc
                        scaleY = sc
                        val dirY = if (clockTop) 1f else -1f
                        translationY = dirY * 48.dp.toPx() * (1f - e)
                        translationX = (0.5f - settings.lockX) * 36.dp.toPx() * (1f - e)
                    }
                    AppIconItem(
                        app = app,
                        settings = settings,
                        showLabel = true,
                        onClick = { viewModel.launch(app) },
                        modifier = enter
                    )
                }
            }

            Dock(
                apps = dockApps,
                settings = settings,
                onClick = viewModel::launch,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )
        }

        Text(
            text = "Kustom",
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .systemBarsPadding()
                .padding(12.dp)
                .graphicsLayer { alpha = ((progress() - 0.5f) / 0.5f).coerceIn(0f, 1f) }
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = 0.22f))
                .clickable { onLongPress() }
                .padding(horizontal = 14.dp, vertical = 7.dp)
        )
    }
}

/** Widget jam di home screen: titik tujuan animasi morph dari lock screen. */
@Composable
private fun HomeClockWidget(
    settings: ZeruuSettings,
    now: java.time.LocalDateTime,
    hidden: Boolean,
    progress: () -> Float,
    onBounds: (Rect) -> Unit,
    modifier: Modifier = Modifier
) {
    val align = when (settings.homeClockAlign) {
        1 -> Alignment.CenterHorizontally
        2 -> Alignment.End
        else -> Alignment.Start
    }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()) }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp),
        horizontalAlignment = align
    ) {
        Box(
            Modifier
                .onGloballyPositioned { onBounds(it.boundsInRoot()) }
                .graphicsLayer { alpha = if (hidden) 0f else 1f }
        ) {
            LivingClockText(settings, settings.homeClockSize, now)
        }
        if (settings.showDate) {
            Text(
                text = now.format(dateFormatter),
                color = Color.White.copy(alpha = 0.88f),
                fontSize = 15.sp,
                style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.3f), Offset.Zero, 6f)),
                modifier = Modifier.graphicsLayer {
                    alpha = ((progress() - 0.5f) / 0.5f).coerceIn(0f, 1f)
                }
            )
        }
    }
}

@Composable
private fun AppIconItem(
    app: AppInfo,
    settings: ZeruuSettings,
    showLabel: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium * settings.animSpeed
        ),
        label = "iconPress"
    )
    val shape: Shape? = when (settings.iconShape) {
        1 -> CircleShape
        2 -> RoundedCornerShape(percent = 30)
        3 -> RoundedCornerShape(percent = 18)
        else -> null
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(settings.iconSize.dp)
                .then(if (shape != null) Modifier.clip(shape) else Modifier)
        )
        if (showLabel && settings.showLabels) {
            Text(
                text = app.label,
                color = Color.White,
                fontSize = settings.labelSize.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(top = 6.dp)
                    .padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
private fun Dock(
    apps: List<AppInfo>,
    settings: ZeruuSettings,
    onClick: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!settings.dockEnabled || apps.isEmpty()) return
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(settings.dockRadius.dp))
            .background(Color.White.copy(alpha = settings.dockAlpha))
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        apps.forEach { app ->
            AppIconItem(app = app, settings = settings, showLabel = false, onClick = { onClick(app) })
        }
    }
}
