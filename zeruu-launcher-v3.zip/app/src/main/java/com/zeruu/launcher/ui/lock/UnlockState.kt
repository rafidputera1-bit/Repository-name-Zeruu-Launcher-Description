package com.zeruu.launcher.ui.lock

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect

/**
 * Satu-satunya sumber kebenaran untuk transisi lock screen ke home.
 * progress: 0 = lock screen penuh, 1 = home screen penuh.
 * Jam, wallpaper redup, ikon, dan dock semuanya membaca nilai ini.
 */
@Stable
class UnlockState {
    val progress = Animatable(1f)
    var lockVisible by mutableStateOf(false)
    var editMode by mutableStateOf(false)
    /** Posisi jam di home screen (koordinat root), tujuan akhir animasi morph. */
    var homeClockBounds by mutableStateOf(Rect.Zero)

    suspend fun showLock() {
        editMode = false
        lockVisible = true
        progress.snapTo(0f)
    }

    suspend fun drag(delta: Float) {
        progress.snapTo((progress.value + delta).coerceIn(0f, 1f))
    }

    suspend fun animateTo(target: Float, speed: Float, bounce: Float) {
        progress.animateTo(
            target,
            spring(
                dampingRatio = (1f - 0.45f * bounce).coerceIn(0.5f, 1f),
                stiffness = 140f * speed.coerceIn(0.4f, 2.5f)
            )
        )
        if (target >= 1f) {
            progress.snapTo(1f)
            lockVisible = false
        }
    }
}
