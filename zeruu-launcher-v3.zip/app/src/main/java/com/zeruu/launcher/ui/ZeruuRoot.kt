package com.zeruu.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.zeruu.launcher.ui.home.HomeScreen
import com.zeruu.launcher.ui.home.HomeViewModel
import com.zeruu.launcher.ui.lock.LockLayer
import com.zeruu.launcher.ui.lock.UnlockState
import com.zeruu.launcher.ui.settings.CustomizeScreen
import com.zeruu.launcher.ui.settings.SettingsViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ZeruuRoot(
    homeViewModel: HomeViewModel,
    settingsViewModel: SettingsViewModel,
    unlockSignal: Int
) {
    val settings by settingsViewModel.settings.collectAsState()
    val scope = rememberCoroutineScope()
    val unlock = remember { UnlockState() }
    var showCustomize by remember { mutableStateOf(false) }
    var systemMode by remember { mutableStateOf(false) }

    // Setelah pengguna membuka kunci sistem: jam muncul besar di posisi lock lalu mengalir ke widget home.
    LaunchedEffect(unlockSignal) {
        if (unlockSignal > 0 && settings.systemUnlockAnim && !showCustomize) {
            systemMode = true
            unlock.showLock()
            delay(140)
            unlock.animateTo(1f, settings.animSpeed, settings.animBounce)
            systemMode = false
        }
    }

    BackHandler(enabled = showCustomize) { showCustomize = false }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(
            viewModel = homeViewModel,
            settings = settings,
            progress = { unlock.progress.value },
            clockHidden = unlock.lockVisible,
            onClockBounds = { unlock.homeClockBounds = it },
            onLongPress = { showCustomize = true },
            onDoubleTap = { scope.launch { unlock.showLock() } }
        )

        if (unlock.lockVisible) {
            LockLayer(
                settings = settings,
                unlock = unlock,
                systemMode = systemMode,
                onMoveCommit = { x, y -> settingsViewModel.update { it.copy(lockX = x, lockY = y) } }
            )
        }

        val ms = (320 / settings.animSpeed).toInt()
        AnimatedVisibility(
            visible = showCustomize,
            enter = slideInVertically(tween(ms)) { it / 6 } + fadeIn(tween(ms)),
            exit = slideOutVertically(tween(ms)) { it / 6 } + fadeOut(tween(ms))
        ) {
            CustomizeScreen(
                settings = settings,
                onChange = { settingsViewModel.update(it) },
                onClose = { showCustomize = false },
                onPreviewLock = {
                    showCustomize = false
                    scope.launch { delay(280); unlock.showLock() }
                },
                onEditLockClock = {
                    showCustomize = false
                    scope.launch { delay(280); unlock.showLock(); unlock.editMode = true }
                }
            )
        }
    }
}
