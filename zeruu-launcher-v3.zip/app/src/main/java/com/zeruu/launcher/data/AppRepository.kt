package com.zeruu.launcher.data

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Process
import android.widget.Toast
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppRepository(context: Context) {

    private val appContext = context.applicationContext
    private val launcherApps = appContext.getSystemService(LauncherApps::class.java)

    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        launcherApps.getActivityList(null, Process.myUserHandle())
            .filter { it.componentName.packageName != appContext.packageName }
            .map { info ->
                AppInfo(
                    label = info.label.toString(),
                    componentName = info.componentName,
                    icon = info.getBadgedIcon(0)
                        .toBitmap(ICON_PX, ICON_PX)
                        .asImageBitmap()
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    fun launch(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.componentName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            appContext.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(appContext, "Aplikasi tidak dapat dibuka", Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(appContext, "Aplikasi tidak dapat dibuka", Toast.LENGTH_SHORT).show()
        }
    }

    fun registerCallback(callback: LauncherApps.Callback) = launcherApps.registerCallback(callback)

    fun unregisterCallback(callback: LauncherApps.Callback) = launcherApps.unregisterCallback(callback)

    private companion object {
        const val ICON_PX = 128
    }
}
