package com.zeruu.launcher.admin

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/** Penerima admin perangkat. Hanya meminta kebijakan "kunci layar", tidak ada akses lain. */
class ZeruuAdminReceiver : DeviceAdminReceiver()

/** Mematikan layar dengan cara resmi Android: DevicePolicyManager.lockNow() (perlu izin admin dari pengguna). */
object ScreenOff {

    private fun component(context: Context) = ComponentName(context, ZeruuAdminReceiver::class.java)

    private fun dpm(context: Context) = context.getSystemService(DevicePolicyManager::class.java)

    fun isActive(context: Context): Boolean = dpm(context)?.isAdminActive(component(context)) == true

    fun lockNow(context: Context) {
        runCatching { dpm(context)?.lockNow() }
    }

    fun requestIntent(context: Context): Intent =
        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component(context))
            .putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Zeruu hanya memakai izin ini untuk mematikan layar saat kamu mengetuk dua kali di lock screen."
            )

    fun deactivate(context: Context) {
        runCatching { dpm(context)?.removeActiveAdmin(component(context)) }
    }
}
