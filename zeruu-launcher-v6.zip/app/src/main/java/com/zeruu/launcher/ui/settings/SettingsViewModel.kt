package com.zeruu.launcher.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.zeruu.launcher.data.SettingsRepository
import com.zeruu.launcher.data.ZeruuSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SettingsRepository(application)
    private val _settings = MutableStateFlow(repository.load())
    val settings: StateFlow<ZeruuSettings> = _settings.asStateFlow()

    fun update(transform: (ZeruuSettings) -> ZeruuSettings) {
        _settings.update(transform)
        repository.save(_settings.value)
    }
}
