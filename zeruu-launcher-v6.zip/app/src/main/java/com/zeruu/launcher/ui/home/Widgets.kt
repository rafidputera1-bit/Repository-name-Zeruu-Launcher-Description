package com.zeruu.launcher.ui.home

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.zeruu.launcher.ui.glass.glassPanel

/** Pembungkus widget: mendeteksi tekan lama tanpa menghalangi ketukan biasa ke widget. */
class WidgetContainer(
    context: Context,
    private val onLongPressAt: (Float, Float) -> Unit
) : FrameLayout(context) {

    private var longPressed = false
    private val detector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onLongPress(e: MotionEvent) {
                longPressed = true
                onLongPressAt(e.x, e.y)
            }
        }
    )

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (longPressed) return true
        detector.onTouchEvent(ev)
        return longPressed
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (longPressed) {
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                longPressed = false
            }
            return true
        }
        return super.onTouchEvent(event)
    }
}

/**
 * Widget Android di beranda. Tahan lama lalu seret untuk memindahkan;
 * tahan lama tanpa menggeser untuk menu (ukuran, jam utama, hapus).
 */
@Composable
fun WidgetItem(
    entry: WidgetEntry,
    vm: HomeViewModel,
    drag: DragState,
    isClock: Boolean,
    widthDp: Int,
    heightDp: Int,
    onBounds: (Rect) -> Unit,
    modifier: Modifier = Modifier
) {
    var menuOpen by remember { mutableStateOf(false) }
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val request = drag.menuRequest
    LaunchedEffect(request) {
        if (request == entry.id) {
            menuOpen = true
            drag.menuRequest = null
        }
    }
    val info = remember(entry.data.id) { vm.widgetInfo(entry.data.id) }
    if (info == null) return

    Box(
        modifier
            .fillMaxSize()
            .padding(3.dp)
            .clip(RoundedCornerShape(22.dp))
            .onGloballyPositioned {
                bounds = it.boundsInRoot()
                onBounds(bounds)
            }
    ) {
        AndroidView(
            factory = { ctx ->
                WidgetContainer(ctx) { x, y -> drag.begin(entry.id, bounds.topLeft + Offset(x, y)) }.also { c ->
                    vm.createWidgetView(ctx, entry.data.id)?.let { c.addView(it) }
                }
            },
            update = { c ->
                (c.getChildAt(0) as? AppWidgetHostView)
                    ?.updateAppWidgetSize(null, widthDp, heightDp, widthDp, heightDp)
            },
            modifier = Modifier.fillMaxSize()
        )
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            val items = listOf(
                (if (isClock) "Lepas dari jam utama" else "Jadikan jam utama (tujuan animasi jam)") to
                    { vm.toggleClockWidget(entry.data.id) },
                "Lebih lebar" to { vm.resizeWidget(entry.data.id, 1, 0) },
                "Lebih sempit" to { vm.resizeWidget(entry.data.id, -1, 0) },
                "Lebih tinggi" to { vm.resizeWidget(entry.data.id, 0, 1) },
                "Lebih pendek" to { vm.resizeWidget(entry.data.id, 0, -1) },
                "Hapus widget" to { vm.removeEntry(entry.id) }
            )
            items.forEach { (title, action) ->
                DropdownMenuItem(text = { Text(title) }, onClick = { menuOpen = false; action() })
            }
        }
    }
}

/** Pemilih widget: daftar semua widget yang disediakan aplikasi terpasang. */
@Composable
fun WidgetPicker(
    providers: List<AppWidgetProviderInfo>,
    onPick: (AppWidgetProviderInfo) -> Unit,
    onClose: () -> Unit
) {
    val pm = LocalContext.current.packageManager
    val rows = remember(providers) {
        providers.map { info ->
            val label = runCatching { info.loadLabel(pm) }.getOrNull() ?: info.provider.className
            val app = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(info.provider.packageName, 0)).toString() }
                .getOrDefault(info.provider.packageName)
            Triple(info, label.toString(), app)
        }.sortedWith(compareBy({ it.third.lowercase() }, { it.second.lowercase() }))
    }
    BackHandler(enabled = true) { onClose() }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .padding(20.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xF01B1F2E))
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(16.dp)
        ) {
            Text("Pilih widget", color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(bottom = 8.dp))
            if (rows.isEmpty()) {
                Text("Tidak ada widget yang ditemukan.", color = Color.White.copy(alpha = 0.8f))
            }
            LazyColumn(Modifier.weight(1f, fill = false)) {
                items(rows) { (info, label, app) ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(info) }
                            .padding(vertical = 10.dp)
                    ) {
                        Text(label, color = Color.White, fontSize = 16.sp)
                        Text(app, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                    }
                }
            }
            OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Batal") }
        }
    }
}

/** Menu yang muncul saat menahan lama di area kosong beranda. */
@Composable
fun HomeMenu(onAddWidget: () -> Unit, onSettings: () -> Unit, onClose: () -> Unit) {
    BackHandler(enabled = true) { onClose() }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            Modifier
                .padding(24.dp)
                .glassPanel(RoundedCornerShape(28.dp), 0.8f)
                .background(Color(0x99101420))
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(onClick = onAddWidget, modifier = Modifier.fillMaxWidth()) { Text("Tambah widget") }
            Button(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Text("Setelan Zeruu") }
            OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Batal") }
        }
    }
}
