package com.zeruu.launcher.ui.settings

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeruu.launcher.data.ZeruuSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val AboutGradients = listOf(
    listOf(Color(0xFF3B2F9E), Color(0xFF8E5BD6), Color(0xFFF2703B)),
    listOf(Color(0xFF0F2027), Color(0xFF2C5364), Color(0xFF5CE1E6)),
    listOf(Color(0xFFFF512F), Color(0xFFDD2476), Color(0xFF8E2DE2)),
    listOf(Color(0xFF134E5E), Color(0xFF3E8E7E), Color(0xFF71B280)),
    listOf(Color(0xFF0B1020), Color(0xFF28305E), Color(0xFF3A3F6B)),
    listOf(Color(0xFFA18CD1), Color(0xFFD7A8E8), Color(0xFFFBC2EB))
)

@Composable
fun AboutScreen(
    settings: ZeruuSettings,
    onChange: ((ZeruuSettings) -> ZeruuSettings) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val info by produceState<DeviceInfoData?>(initialValue = null) { value = readDeviceInfo(context) }
    val version = remember {
        try { context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    val bgImage by produceState<ImageBitmap?>(initialValue = null, settings.aboutBg, settings.aboutBgStamp) {
        value = if (settings.aboutBg == 6) {
            withContext(Dispatchers.IO) {
                val f = aboutBackgroundFile(context)
                if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null
            }
        } else null
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                if (saveAboutBackground(context, uri)) {
                    onChange { it.copy(aboutBg = 6, aboutBgStamp = System.currentTimeMillis()) }
                }
            }
        }
    }

    PageScaffold("Tentang perangkat", onBack) {
        val d = info
        if (d == null) {
            Text("Membaca info perangkat...")
        } else {
            val gradient = AboutGradients[settings.aboutBg.coerceIn(0, AboutGradients.size - 1)]
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(gradient)),
                contentAlignment = Alignment.Center
            ) {
                val img = bgImage
                if (settings.aboutBg == 6 && img != null) {
                    Image(
                        bitmap = img,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                val shadow = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.45f), blurRadius = 12f))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Zeruu $version", color = Color.White, fontSize = 36.sp, style = shadow)
                    Text(
                        "Berjalan di ${d.osName} - ${d.osSub}",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 13.sp,
                        style = shadow
                    )
                }
            }

            Card(colors = cardColors()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Latar belakang", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AboutGradients.forEachIndexed { i, colors ->
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(colors))
                                    .border(
                                        width = if (settings.aboutBg == i) 3.dp else 1.dp,
                                        color = if (settings.aboutBg == i) MaterialTheme.colorScheme.onSurface else Color.Gray,
                                        shape = CircleShape
                                    )
                                    .clickable { onChange { it.copy(aboutBg = i) } }
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Pilih gambar sendiri") }
                }
            }

            Card(colors = cardColors()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        Text("Nama perangkat", modifier = Modifier.weight(1f))
                        Text(d.deviceName, color = MaterialTheme.colorScheme.primary)
                    }
                    HorizontalDivider()
                    Row(Modifier.fillMaxWidth()) {
                        Text("Penyimpanan", modifier = Modifier.weight(1f))
                        Text(d.storageText, color = MaterialTheme.colorScheme.primary)
                    }
                    LinearProgressIndicator(progress = { d.storageFraction }, modifier = Modifier.fillMaxWidth())
                }
            }

            Card(colors = cardColors()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    InfoRow("Model", d.model)
                    InfoRow("Nomor build", d.build)
                    InfoRow("Prosesor", d.processor)
                    InfoRow("RAM", d.ram)
                    InfoRow("Layar", d.screen)
                    InfoRow("Patch keamanan", d.security)
                    InfoRow("Versi kernel", d.kernel)
                }
            }
            Text("Zeruu Launcher v$version", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}
