package com.zeruu.launcher.ui.clock

import android.graphics.Typeface
import android.text.format.DateFormat
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.zeruu.launcher.data.ZeruuSettings
import kotlinx.coroutines.delay
import java.io.File
import java.time.LocalDateTime
import kotlin.math.max
import kotlin.math.roundToInt

/** Waktu sekarang, diperbarui tepat di pergantian menit. */
@Composable
fun rememberNow(): State<LocalDateTime> = produceState(initialValue = LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(60_000L - (System.currentTimeMillis() % 60_000L))
    }
}

private val CondensedFamily: FontFamily by lazy {
    FontFamily(Typeface.create("sans-serif-condensed", Typeface.NORMAL))
}

private val BlackFamily: FontFamily by lazy {
    FontFamily(Typeface.create("sans-serif-black", Typeface.NORMAL))
}

/** Menyempitkan jam secara horizontal (lebar layout ikut mengecil), untuk tampilan tinggi-ramping ala Flux. */
private fun Modifier.condense(xScale: Float): Modifier =
    if (xScale >= 0.999f) this else this.layout { measurable, constraints ->
        val p = measurable.measure(constraints.copy(minWidth = 0, maxWidth = Constraints.Infinity))
        val w = (p.width * xScale).roundToInt()
        layout(w, p.height) {
            p.placeWithLayer((w - p.width) / 2, 0) { scaleX = xScale }
        }
    }

/** 0 tipis, 1 tebal, 2 serif, 3 ramping, 4 hitam, 5 tulisan, 6 mono, 7 font sendiri, 8 Flux tinggi. */
private fun fontFor(style: Int, custom: FontFamily?): Pair<FontFamily, FontWeight> = when (style) {
    1 -> FontFamily.SansSerif to FontWeight.Bold
    2 -> FontFamily.Serif to FontWeight.Normal
    3 -> CondensedFamily to FontWeight.Medium
    4 -> BlackFamily to FontWeight.Normal
    5 -> FontFamily.Cursive to FontWeight.Normal
    6 -> FontFamily.Monospace to FontWeight.Light
    7 -> (custom ?: FontFamily.SansSerif) to FontWeight.Normal
    8 -> FontFamily.SansSerif to FontWeight.Bold
    else -> FontFamily.SansSerif to FontWeight.Light
}

/**
 * Jam Zeruu. Dipakai bersama oleh lock screen, widget jam di beranda, dan overlay morph,
 * sehingga tampilannya selalu identik di semua tempat.
 *
 * Mode liquid glass memakai beberapa lapisan: badan kaca tembus pandang, tepi bercahaya,
 * dan kilap di bagian atas. Tingkatnya diatur lewat clockGlassLevel.
 */
@Composable
fun LivingClockText(
    settings: ZeruuSettings,
    sizeSp: Float,
    now: LocalDateTime,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val systemIs24 = remember { DateFormat.is24HourFormat(context) }
    val use24 = when (settings.clockFormat) {
        1 -> false
        2 -> true
        else -> systemIs24
    }
    val hour = if (use24) now.hour else (now.hour % 12).let { if (it == 0) 12 else it }
    val hh = if (use24) "%02d".format(hour) else hour.toString()
    val mm = "%02d".format(now.minute)
    val text = when {
        settings.clockStacked -> "$hh\n$mm"
        settings.clockColon -> "$hh:$mm"
        else -> "$hh $mm"
    }
    val custom = remember(settings.clockFontStamp, settings.clockStyle) {
        if (settings.clockStyle == 7) {
            val f = File(context.filesDir, "clock_font.ttf")
            if (f.exists()) runCatching { FontFamily(Typeface.createFromFile(f)) }.getOrNull() else null
        } else null
    }
    val (family, weight) = fontFor(settings.clockStyle, custom)
    val tint = Color(settings.clockColor)
    val base = TextStyle(
        fontSize = sizeSp.sp,
        fontFamily = family,
        fontWeight = weight,
        letterSpacing = (-sizeSp * 0.01f).sp,
        lineHeight = if (settings.clockStacked) (sizeSp * 0.95f).sp else TextUnit.Unspecified,
        textAlign = TextAlign.Center
    )

    val xScale = if (settings.clockStyle == 8) 0.58f else 1f
    Box(modifier.condense(xScale)) {
        if (settings.clockGlass) {
            val lv = settings.clockGlassLevel.coerceIn(0f, 1f)
            val shadow = if (settings.clockGlow) {
                Shadow(Color(settings.accent).copy(alpha = 0.55f), Offset.Zero, sizeSp * 0.3f)
            } else {
                Shadow(Color.Black.copy(alpha = 0.22f * lv), Offset(0f, sizeSp * 0.03f), sizeSp * 0.1f)
            }
            // 1. Badan kaca
            Text(
                text = text,
                style = base.copy(
                    brush = Brush.verticalGradient(
                        0f to tint.copy(alpha = 0.30f + 0.25f * (1f - lv)),
                        1f to tint.copy(alpha = 0.10f + 0.18f * (1f - lv))
                    ),
                    shadow = shadow
                )
            )
            // 2. Tepi kaca
            Text(
                text = text,
                style = base.copy(
                    color = tint.copy(alpha = 0.30f + 0.60f * lv),
                    drawStyle = Stroke(width = max(1f, sizeSp * 0.02f * (0.5f + lv)))
                )
            )
            // 3. Kilap atas
            Text(
                text = text,
                style = base.copy(
                    brush = Brush.verticalGradient(
                        0f to tint.copy(alpha = 0.9f * lv),
                        0.42f to tint.copy(alpha = 0.12f * lv),
                        0.5f to Color.Transparent,
                        1f to Color.Transparent
                    )
                )
            )
        } else {
            val glow: Shadow? = if (settings.clockGlow) {
                Shadow(Color(settings.accent).copy(alpha = 0.7f), Offset.Zero, sizeSp * 0.4f)
            } else null
            Text(text = text, style = base.copy(color = tint.copy(alpha = 0.94f), shadow = glow))
        }
    }
}
