package com.zeruu.launcher.ui.home

import com.zeruu.launcher.data.AppInfo
import com.zeruu.launcher.data.FolderData
import com.zeruu.launcher.data.WidgetData

sealed interface HomeEntry { val id: String }

data class AppEntry(val app: AppInfo, val size: Int) : HomeEntry {
    override val id: String get() = "a:" + app.key
}

data class FolderEntry(val folder: FolderData, val apps: List<AppInfo>) : HomeEntry {
    override val id: String get() = "f:" + folder.id
}

data class WidgetEntry(val data: WidgetData) : HomeEntry {
    override val id: String get() = "w:" + data.id
}

fun HomeEntry.span(): Pair<Int, Int> = when (this) {
    is WidgetEntry -> data.spanC to data.spanR
    else -> 1 to 1
}

fun sizeScaleOf(size: Int): Float = when (size) {
    0 -> 0.8f
    2 -> 1.3f
    else -> 1f
}
