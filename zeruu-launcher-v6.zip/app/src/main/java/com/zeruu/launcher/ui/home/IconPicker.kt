package com.zeruu.launcher.ui.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.zeruu.launcher.data.AppInfo

/** Mengembalikan fungsi "ubah ikon aplikasi": membuka pemilih gambar lalu menyimpan ikon kustom. */
@Composable
fun rememberIconPicker(vm: HomeViewModel): (AppInfo) -> Unit {
    var pending by remember { mutableStateOf<AppInfo?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val app = pending
        if (uri != null && app != null) vm.setCustomIcon(app, uri)
        pending = null
    }
    return remember(launcher) {
        { app: AppInfo ->
            pending = app
            launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
    }
}
