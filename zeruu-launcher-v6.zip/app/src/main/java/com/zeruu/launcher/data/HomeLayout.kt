package com.zeruu.launcher.data

data class FolderData(val id: String, val name: String, val apps: List<String>)

/** Widget Android di beranda. Ukuran dalam sel grid. */
data class WidgetData(val id: Int, val provider: String, val spanC: Int, val spanR: Int)

/**
 * Susunan beranda. Setiap halaman berisi id entri berurutan: "a:<komponen>" aplikasi,
 * "f:<id>" folder, atau "w:<id>" widget. Posisi sel dihitung dari urutan (gaya iOS, tanpa celah).
 */
data class HomeLayout(
    val pages: List<List<String>> = listOf(emptyList()),
    val dock: List<String> = emptyList(),
    val folders: Map<String, FolderData> = emptyMap(),
    val sizes: Map<String, Int> = emptyMap(),   // kunci aplikasi -> 0 kecil, 1 normal, 2 besar
    val seen: Set<String> = emptySet(),
    val widgets: Map<Int, WidgetData> = emptyMap(),
    val clockWidgetId: Int = -1                 // widget jam yang menjadi tujuan animasi jam lock screen
)
