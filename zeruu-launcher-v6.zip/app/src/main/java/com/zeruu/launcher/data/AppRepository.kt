package com.zeruu.launcher.data

import android.app.ActivityOptions
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Process
import android.provider.Settings
import android.util.LruCache
import android.view.View
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class AppRepository(context: Context) {

    private val appContext = context.applicationContext
    private val launcherApps = appContext.getSystemService(LauncherApps::class.java)
    private val infos = ConcurrentHashMap<String, LauncherActivityInfo>()
    private val iconCache = LruCache<String, ImageBitmap>(220)
    private val iconDir = File(appContext.filesDir, "icons").apply { mkdirs() }

    /** Cepat: hanya nama dan komponen. Ikon dimuat belakangan per item yang terlihat. */
    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val list = launcherApps.getActivityList(null, Process.myUserHandle())
            .filter { it.componentName.packageName != appContext.packageName }
        infos.clear()
        list.forEach { infos[it.componentName.flattenToString()] = it }
        list.map { AppInfo(it.label.toString(), it.componentName) }
            .sortedBy { it.label.lowercase() }
    }

    fun cachedIcon(key: String): ImageBitmap? = iconCache.get(key)

    suspend fun loadIcon(app: AppInfo): ImageBitmap? = withContext(Dispatchers.Default) {
        iconCache.get(app.key)?.let { return@withContext it }
        val custom = customFile(app.key)
        if (custom.exists()) {
            val bmp = BitmapFactory.decodeFile(custom.path)?.asImageBitmap()
            if (bmp != null) {
                iconCache.put(app.key, bmp)
                return@withContext bmp
            }
        }
        val info = infos[app.key] ?: return@withContext null
        try {
            val bmp = info.getBadgedIcon(0).toBitmap(ICON_PX, ICON_PX).asImageBitmap()
            iconCache.put(app.key, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }

    fun invalidateIcons(packageName: String) {
        iconCache.snapshot().keys
            .filter { it.startsWith("$packageName/") && !customFile(it).exists() }
            .forEach { iconCache.remove(it) }
    }

    // ----- Ikon kustom (gambar dari galeri) -----
    private fun customFile(key: String) =
        File(iconDir, key.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".png")

    suspend fun setCustomIcon(app: AppInfo, uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            appContext.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val src = appContext.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return@withContext false
            val side = minOf(src.width, src.height)
            val square = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(square, ICON_PX, ICON_PX, true)
            customFile(app.key).outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            iconCache.put(app.key, out.asImageBitmap())
            true
        } catch (e: Exception) {
            false
        }
    }

    fun resetCustomIcon(app: AppInfo) {
        customFile(app.key).delete()
        iconCache.remove(app.key)
    }

    // ----- Membuka, info, copot -----
    fun launch(app: AppInfo, view: View?, left: Int, top: Int, width: Int, height: Int) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.componentName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        // Animasi zoom dari ikon (mirip iOS).
        val options = if (view != null && width > 0 && height > 0) {
            ActivityOptions.makeScaleUpAnimation(view, left, top, width, height).toBundle()
        } else null
        try {
            appContext.startActivity(intent, options)
        } catch (e: ActivityNotFoundException) {
            toast("Aplikasi tidak dapat dibuka")
        } catch (e: SecurityException) {
            toast("Aplikasi tidak dapat dibuka")
        }
    }

    fun openAppInfo(packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { appContext.startActivity(intent) } catch (e: Exception) { toast("Tidak dapat membuka info aplikasi") }
    }

    fun uninstall(packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE, Uri.fromParts("package", packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { appContext.startActivity(intent) } catch (e: Exception) { toast("Aplikasi sistem tidak bisa dicopot") }
    }

    fun toast(text: String) = Toast.makeText(appContext, text, Toast.LENGTH_SHORT).show()

    fun registerCallback(callback: LauncherApps.Callback) = launcherApps.registerCallback(callback)

    fun unregisterCallback(callback: LauncherApps.Callback) = launcherApps.unregisterCallback(callback)

    private companion object {
        const val ICON_PX = 128
    }
}
