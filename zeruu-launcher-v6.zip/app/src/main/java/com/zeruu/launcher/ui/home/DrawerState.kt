package com.zeruu.launcher.ui.home

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Stable

/** progress: 0 = app drawer tertutup, 1 = terbuka penuh. Mengikuti gerakan jari, lalu menetap dengan pegas. */
@Stable
class DrawerState {
    val progress = Animatable(0f)

    suspend fun drag(delta: Float) {
        progress.snapTo((progress.value + delta).coerceIn(0f, 1f))
    }

    suspend fun settle(open: Boolean, speed: Float) {
        progress.animateTo(
            if (open) 1f else 0f,
            spring(dampingRatio = 0.85f, stiffness = 380f * speed.coerceIn(0.4f, 2.5f))
        )
    }
}
