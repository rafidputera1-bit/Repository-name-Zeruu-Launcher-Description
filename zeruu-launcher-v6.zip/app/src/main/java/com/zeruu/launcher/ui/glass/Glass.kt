package com.zeruu.launcher.ui.glass

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** Panel liquid glass: isi tembus pandang bergradasi dan tepi bercahaya di bagian atas. */
fun Modifier.glassPanel(shape: Shape, level: Float): Modifier {
    val lv = level.coerceIn(0f, 1f)
    return this
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(
                    Color.White.copy(alpha = 0.10f + 0.22f * lv),
                    Color.White.copy(alpha = 0.04f + 0.08f * lv)
                )
            ),
            shape
        )
        .border(
            1.dp,
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.25f + 0.55f * lv), Color.White.copy(alpha = 0.05f))
            ),
            shape
        )
}
