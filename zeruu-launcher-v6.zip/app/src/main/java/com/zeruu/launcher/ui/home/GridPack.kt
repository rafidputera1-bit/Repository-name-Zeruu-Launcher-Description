package com.zeruu.launcher.ui.home

data class Placement(val row: Int, val col: Int, val spanR: Int, val spanC: Int)

/**
 * Menempatkan entri berurutan ke grid: tiap entri mengambil kotak (lebar, tinggi) pertama yang kosong,
 * dicari baris demi baris. Mengembalikan penempatan untuk entri-entri awal yang muat;
 * entri yang tidak muat (dan sesudahnya) pindah ke halaman berikutnya.
 */
fun packEntries(spans: List<Pair<Int, Int>>, cols: Int, rows: Int): List<Placement> {
    if (cols <= 0 || rows <= 0) return emptyList()
    val used = Array(rows) { BooleanArray(cols) }
    val result = mutableListOf<Placement>()
    for ((spanC, spanR) in spans) {
        val w = spanC.coerceIn(1, cols)
        val h = spanR.coerceIn(1, rows)
        var placed: Placement? = null
        search@ for (r in 0..rows - h) {
            for (c in 0..cols - w) {
                var free = true
                for (rr in r until r + h) for (cc in c until c + w) if (used[rr][cc]) free = false
                if (free) {
                    placed = Placement(r, c, h, w)
                    break@search
                }
            }
        }
        val p = placed ?: break
        for (rr in p.row until p.row + p.spanR) for (cc in p.col until p.col + p.spanC) used[rr][cc] = true
        result += p
    }
    return result
}
