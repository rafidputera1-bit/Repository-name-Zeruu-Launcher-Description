package com.zeruu.launcher.ui.home

import android.app.Activity
import android.app.Application
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.net.Uri
import android.os.UserHandle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zeruu.launcher.data.AppInfo
import com.zeruu.launcher.data.AppRepository
import com.zeruu.launcher.data.FolderData
import com.zeruu.launcher.data.HomeLayout
import com.zeruu.launcher.data.HomeLayoutRepository
import com.zeruu.launcher.data.WidgetController
import com.zeruu.launcher.data.WidgetData
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.ceil

data class HomeUiState(
    val apps: List<AppInfo> = emptyList(),          // semua aplikasi (isi app drawer)
    val pages: List<List<HomeEntry>> = listOf(emptyList()),
    val dock: List<AppInfo> = emptyList(),
    val clockWidgetId: Int = -1,
    val loaded: Boolean = false
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val layoutRepo = HomeLayoutRepository(application)
    private val widgets = WidgetController(application)

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    private val _iconVersion = MutableStateFlow(0)
    val iconVersion: StateFlow<Int> = _iconVersion.asStateFlow()

    private val _bindRequest = MutableStateFlow<Intent?>(null)
    val bindRequest: StateFlow<Intent?> = _bindRequest.asStateFlow()

    private var allApps: List<AppInfo> = emptyList()
    private var layout = HomeLayout()
    private var cols = 4
    private var firstRows = 4
    private var minPages = 3
    private var loaded = false
    private var loadJob: Job? = null
    private var pendingId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null

    private val packageCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String, user: UserHandle) = refresh()
        override fun onPackageAdded(packageName: String, user: UserHandle) = refresh()
        override fun onPackageChanged(packageName: String, user: UserHandle) = refresh(packageName)
        override fun onPackagesAvailable(
            packageNames: Array<out String>, user: UserHandle, replacing: Boolean
        ) = refresh()

        override fun onPackagesUnavailable(
            packageNames: Array<out String>, user: UserHandle, replacing: Boolean
        ) = refresh()
    }

    init {
        repository.registerCallback(packageCallback)
        refresh()
    }

    // ----- Pemuatan -----
    fun refresh(changedPackage: String? = null) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            if (changedPackage != null) repository.invalidateIcons(changedPackage)
            val apps = repository.loadApps()
            allApps = apps
            val keys = apps.map { it.key }.toSet()
            layout = if (!layoutRepo.hasLayout()) defaultLayout(apps) else reconcile(layoutRepo.load(), keys, apps)
            loaded = true
            commit(layout)
        }
    }

    /** Dipanggil UI: jumlah kolom, baris halaman pertama, dan jumlah halaman minimum. */
    fun setGrid(cols: Int, firstRows: Int, minPages: Int) {
        if (this.cols == cols && this.firstRows == firstRows && this.minPages == minPages) return
        this.cols = cols
        this.firstRows = firstRows
        this.minPages = minPages
        if (loaded) commit(layout)
    }

    private fun rowsFor(page: Int) = if (page == 0) firstRows else 6

    private fun spanOf(id: String, l: HomeLayout): Pair<Int, Int> {
        if (id.startsWith("w:")) {
            val w = l.widgets[id.drop(2).toIntOrNull() ?: -1]
            if (w != null) return w.spanC to w.spanR
        }
        return 1 to 1
    }

    /** Mendorong kelebihan isi ke halaman berikutnya dan menjaga jumlah halaman minimum. */
    private fun normalize(l: HomeLayout): HomeLayout {
        val pages = l.pages.map { it.toMutableList() }.toMutableList()
        if (pages.isEmpty()) pages += mutableListOf<String>()
        var i = 0
        while (i < pages.size) {
            val p = pages[i]
            val fit = packEntries(p.map { spanOf(it, l) }, cols, rowsFor(i)).size
            if (fit < p.size) {
                val overflow = p.subList(fit, p.size).toList()
                while (p.size > fit) p.removeAt(p.size - 1)
                if (i + 1 >= pages.size) pages += mutableListOf<String>()
                pages[i + 1].addAll(0, overflow)
            }
            i++
        }
        while (pages.size < minPages) pages += mutableListOf<String>()
        while (pages.size > minPages && pages.last().isEmpty()) pages.removeAt(pages.size - 1)
        return l.copy(pages = pages)
    }

    private fun commit(l: HomeLayout) {
        layout = normalize(l)
        layoutRepo.save(layout)
        publish()
    }

    private fun publish() {
        val byKey = allApps.associateBy { it.key }
        val pages = layout.pages.map { page ->
            page.mapNotNull { id ->
                when {
                    id.startsWith("a:") -> byKey[id.drop(2)]?.let { AppEntry(it, layout.sizes[it.key] ?: 1) }
                    id.startsWith("f:") -> layout.folders[id.drop(2)]?.let { f ->
                        FolderEntry(f, f.apps.mapNotNull { byKey[it] })
                    }
                    id.startsWith("w:") -> layout.widgets[id.drop(2).toIntOrNull() ?: -1]?.let { WidgetEntry(it) }
                    else -> null
                }
            }
        }
        _state.value = HomeUiState(
            apps = allApps,
            pages = pages.ifEmpty { listOf(emptyList()) },
            dock = layout.dock.mapNotNull { byKey[it] },
            clockWidgetId = layout.clockWidgetId,
            loaded = true
        )
    }

    private fun reconcile(l: HomeLayout, keys: Set<String>, apps: List<AppInfo>): HomeLayout {
        val folders = l.folders
            .mapValues { (_, f) -> f.copy(apps = f.apps.filter { it in keys }) }
            .filterValues { it.apps.isNotEmpty() }
        // Widget yang penyedianya sudah tidak ada dibuang.
        val liveWidgets = l.widgets.filter { (id, _) -> widgets.infoFor(id) != null }
        (l.widgets.keys - liveWidgets.keys).forEach { widgets.release(it) }
        val pages = l.pages.map { page ->
            page.filter { id ->
                when {
                    id.startsWith("a:") -> id.drop(2) in keys
                    id.startsWith("f:") -> id.drop(2) in folders
                    id.startsWith("w:") -> (id.drop(2).toIntOrNull() ?: -1) in liveWidgets
                    else -> false
                }
            }
        }
        var seen = l.seen.filter { it in keys }.toSet()
        val fresh = apps.map { it.key }.filter { it !in seen }
        val withFresh = pages.toMutableList()
        if (withFresh.isEmpty()) withFresh += emptyList<String>()
        if (fresh.isNotEmpty()) {
            withFresh[withFresh.lastIndex] = withFresh.last() + fresh.map { "a:$it" }
            seen = seen + fresh
        }
        return l.copy(
            pages = withFresh,
            dock = l.dock.filter { it in keys },
            folders = folders,
            seen = seen,
            widgets = liveWidgets,
            clockWidgetId = if (l.clockWidgetId in liveWidgets) l.clockWidgetId else -1
        )
    }

    // ----- Penyusunan beranda -----
    private fun locate(id: String): Pair<Int, Int>? {
        layout.pages.forEachIndexed { p, list ->
            val i = list.indexOf(id)
            if (i >= 0) return p to i
        }
        return null
    }

    private fun containsApp(key: String): Boolean =
        layout.pages.any { "a:$key" in it } || layout.folders.values.any { key in it.apps }

    private fun mutablePages() = layout.pages.map { it.toMutableList() }.toMutableList()

    fun addToHome(app: AppInfo) {
        if (containsApp(app.key)) {
            repository.toast("Sudah ada di beranda")
            return
        }
        val pages = mutablePages()
        val target = pages.indices.firstOrNull { i ->
            packEntries((pages[i] + "a:${app.key}").map { spanOf(it, layout) }, cols, rowsFor(i)).size == pages[i].size + 1
        } ?: pages.lastIndex
        pages[target].add("a:${app.key}")
        commit(layout.copy(pages = pages))
        repository.toast("Ditambahkan ke beranda")
    }

    /** Memindahkan entri ke halaman dan urutan tertentu (entri lain bergeser). */
    fun moveEntry(id: String, toPage: Int, toIndex: Int) {
        val from = locate(id) ?: return
        val pages = mutablePages()
        pages[from.first].removeAt(from.second)
        val tp = toPage.coerceIn(0, pages.lastIndex)
        val ti = toIndex.coerceIn(0, pages[tp].size)
        pages[tp].add(ti, id)
        commit(layout.copy(pages = pages))
    }

    /** Menjatuhkan aplikasi ke atas entri lain: membuat folder baru atau menambah ke folder. */
    fun dropOnto(draggedId: String, targetId: String) {
        if (!draggedId.startsWith("a:") || draggedId == targetId) return
        if (targetId.startsWith("w:")) return
        val key = draggedId.drop(2)
        val to = locate(targetId) ?: return
        val pages = mutablePages()
        val folders = layout.folders.toMutableMap()
        if (targetId.startsWith("f:")) {
            val f = folders[targetId.drop(2)] ?: return
            folders[f.id] = f.copy(apps = f.apps + key)
        } else {
            val fid = "f" + System.currentTimeMillis().toString(36)
            folders[fid] = FolderData(fid, "Folder", listOf(targetId.drop(2), key))
            pages[to.first][to.second] = "f:$fid"
        }
        pages.forEach { it.remove(draggedId) }
        commit(layout.copy(pages = pages, folders = folders))
    }

    /** Aplikasi: dihapus dari beranda. Folder: dibubarkan. Widget: dihapus dan dilepas dari host. */
    fun removeEntry(id: String) {
        val loc = locate(id) ?: return
        val pages = mutablePages()
        when {
            id.startsWith("f:") -> {
                val f = layout.folders[id.drop(2)]
                pages[loc.first].removeAt(loc.second)
                if (f != null) pages[loc.first].addAll(loc.second, f.apps.map { "a:$it" })
                commit(layout.copy(pages = pages, folders = layout.folders - id.drop(2)))
            }
            id.startsWith("w:") -> {
                val wid = id.drop(2).toIntOrNull() ?: return
                pages[loc.first].removeAt(loc.second)
                widgets.release(wid)
                commit(
                    layout.copy(
                        pages = pages,
                        widgets = layout.widgets - wid,
                        clockWidgetId = if (layout.clockWidgetId == wid) -1 else layout.clockWidgetId
                    )
                )
            }
            else -> {
                pages[loc.first].removeAt(loc.second)
                commit(layout.copy(pages = pages))
            }
        }
    }

    fun removeFromFolder(folderId: String, appKey: String) {
        val f = layout.folders[folderId] ?: return
        val loc = locate("f:$folderId") ?: return
        val remaining = f.apps - appKey
        val pages = mutablePages()
        val folders = layout.folders.toMutableMap()
        when (remaining.size) {
            0 -> {
                pages[loc.first].removeAt(loc.second)
                folders.remove(folderId)
            }
            1 -> {
                pages[loc.first][loc.second] = "a:${remaining[0]}"
                folders.remove(folderId)
            }
            else -> folders[folderId] = f.copy(apps = remaining)
        }
        pages[loc.first].add((loc.second + 1).coerceAtMost(pages[loc.first].size), "a:$appKey")
        commit(layout.copy(pages = pages, folders = folders))
    }

    fun renameFolder(folderId: String, name: String) {
        val f = layout.folders[folderId] ?: return
        commit(layout.copy(folders = layout.folders + (folderId to f.copy(name = name.take(24)))))
    }

    fun setSize(appKey: String, size: Int) {
        commit(layout.copy(sizes = layout.sizes + (appKey to size)))
    }

    /** Menambah halaman kosong di belakang (halaman kosong yang tidak dipakai akan hilang lagi). */
    fun addPage() {
        layout = layout.copy(pages = layout.pages + listOf(emptyList()))
        layoutRepo.save(layout)
        publish()
    }

    // ----- Widget Android -----
    fun startWidgets() = widgets.startListening()

    fun stopWidgets() = widgets.stopListening()

    fun providers(): List<AppWidgetProviderInfo> = widgets.providers()

    fun widgetInfo(id: Int): AppWidgetProviderInfo? = widgets.infoFor(id)

    fun createWidgetView(context: Context, id: Int): AppWidgetHostView? = widgets.createView(context, id)

    /** Langkah 1: alokasikan id dan ikat widget (bisa memunculkan dialog izin sistem). */
    fun beginAddWidget(info: AppWidgetProviderInfo, activity: Activity) {
        cancelPending()
        val id = widgets.allocate()
        pendingId = id
        pendingInfo = info
        if (widgets.tryBind(id, info)) afterBound(activity) else _bindRequest.value = widgets.bindIntent(id, info)
    }

    fun clearBindRequest() {
        _bindRequest.value = null
    }

    fun onBindResult(ok: Boolean, activity: Activity) {
        if (ok) afterBound(activity) else cancelPending()
    }

    /** Langkah 2: sebagian widget punya layar pengaturan sendiri; hasilnya datang lewat MainActivity. */
    private fun afterBound(activity: Activity) {
        val id = pendingId
        if (id < 0) return
        if (widgets.needsConfigure(id)) {
            try {
                widgets.configure(activity, id)
            } catch (e: Exception) {
                finishAdd()
            }
        } else {
            finishAdd()
        }
    }

    fun onConfigureResult(ok: Boolean) {
        if (ok) finishAdd() else cancelPending()
    }

    private fun cancelPending() {
        if (pendingId >= 0) widgets.release(pendingId)
        pendingId = -1
        pendingInfo = null
    }

    private fun finishAdd() {
        val id = pendingId
        val info = pendingInfo
        pendingId = -1
        pendingInfo = null
        if (id < 0 || info == null) return
        val dm = getApplication<Application>().resources.displayMetrics
        val cellW = dm.widthPixels / cols.toFloat()
        val cellH = dm.heightPixels * 0.105f
        val spanC = ceil(info.minWidth / cellW).toInt().coerceIn(1, cols)
        val spanR = ceil(info.minHeight / cellH).toInt().coerceIn(1, 4)
        val entryId = "w:$id"
        val withWidget = layout.copy(
            widgets = layout.widgets + (id to WidgetData(id, info.provider.flattenToString(), spanC, spanR))
        )
        val pages = withWidget.pages.map { it.toMutableList() }.toMutableList()
        val target = pages.indices.firstOrNull { i ->
            packEntries((pages[i] + entryId).map { spanOf(it, withWidget) }, cols, rowsFor(i)).size == pages[i].size + 1
        } ?: pages.lastIndex
        pages[target].add(entryId)
        commit(withWidget.copy(pages = pages))
        repository.toast("Widget ditambahkan")
    }

    /** Mengubah ukuran widget dalam sel grid. */
    fun resizeWidget(id: Int, dC: Int, dR: Int) {
        val w = layout.widgets[id] ?: return
        val updated = w.copy(
            spanC = (w.spanC + dC).coerceIn(1, cols),
            spanR = (w.spanR + dR).coerceIn(1, 6)
        )
        commit(layout.copy(widgets = layout.widgets + (id to updated)))
    }

    /** Menandai widget jam sebagai tujuan animasi jam lock screen (tekan lagi untuk melepas). */
    fun toggleClockWidget(id: Int) {
        commit(layout.copy(clockWidgetId = if (layout.clockWidgetId == id) -1 else id))
    }

    // ----- Membuka, ikon -----
    fun launch(app: AppInfo, view: View?, left: Int, top: Int, width: Int, height: Int) =
        repository.launch(app, view, left, top, width, height)

    fun openInfo(app: AppInfo) = repository.openAppInfo(app.packageName)

    fun uninstall(app: AppInfo) = repository.uninstall(app.packageName)

    fun cachedIcon(app: AppInfo): ImageBitmap? = repository.cachedIcon(app.key)

    suspend fun loadIcon(app: AppInfo): ImageBitmap? = repository.loadIcon(app)

    fun setCustomIcon(app: AppInfo, uri: Uri) {
        viewModelScope.launch {
            if (repository.setCustomIcon(app, uri)) {
                _iconVersion.update { it + 1 }
            } else {
                repository.toast("Gambar tidak dapat dipakai")
            }
        }
    }

    fun resetIcon(app: AppInfo) {
        repository.resetCustomIcon(app)
        _iconVersion.update { it + 1 }
        refresh(app.packageName)
    }

    // ----- Susunan awal -----
    private fun defaultLayout(apps: List<AppInfo>): HomeLayout {
        val pm = getApplication<Application>().packageManager
        fun pkgOf(intent: Intent): String? =
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.takeIf { it != "android" }

        val dockPkgs = listOfNotNull(
            pkgOf(Intent(Intent.ACTION_DIAL)),
            pkgOf(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))),
            pkgOf(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))),
            pkgOf(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        ).distinct()

        val categories = listOf(
            Intent.CATEGORY_APP_GALLERY, Intent.CATEGORY_APP_MARKET, Intent.CATEGORY_APP_CALENDAR,
            Intent.CATEGORY_APP_CALCULATOR, Intent.CATEGORY_APP_CONTACTS, Intent.CATEGORY_APP_MAPS,
            Intent.CATEGORY_APP_MUSIC, Intent.CATEGORY_APP_EMAIL
        )
        val homePkgs = (categories.mapNotNull { pkgOf(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, it)) } +
            listOfNotNull(pkgOf(Intent(Settings.ACTION_SETTINGS))))
            .distinct()
            .filter { it !in dockPkgs }

        fun keyOf(pkg: String): String? = apps.firstOrNull { it.packageName == pkg }?.key

        var dock = dockPkgs.mapNotNull { keyOf(it) }
        var home = homePkgs.mapNotNull { keyOf(it) }
        if (dock.isEmpty()) dock = apps.take(4).map { it.key }
        if (home.size < 8) {
            val used = (dock + home).toSet()
            home = home + apps.map { it.key }.filter { it !in used }.take(8 - home.size)
        }
        return HomeLayout(
            pages = listOf(home.map { "a:$it" }),
            dock = dock,
            seen = apps.map { it.key }.toSet()
        )
    }

    override fun onCleared() {
        repository.unregisterCallback(packageCallback)
        widgets.stopListening()
        super.onCleared()
    }
}
