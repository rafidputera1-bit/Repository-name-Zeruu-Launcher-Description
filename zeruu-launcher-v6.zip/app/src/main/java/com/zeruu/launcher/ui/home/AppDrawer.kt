package com.zeruu.launcher.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import com.zeruu.launcher.data.AppInfo
import com.zeruu.launcher.data.ZeruuSettings
import com.zeruu.launcher.ui.theme.LocalBlurOn
import kotlinx.coroutines.launch

/** App drawer: daftar semua aplikasi A sampai Z + pencarian. Terbuka dengan geser ke atas di beranda. */
@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    vm: HomeViewModel,
    settings: ZeruuSettings,
    drawer: DrawerState,
    launchApp: (AppInfo, Rect) -> Unit,
    onChangeIcon: (AppInfo) -> Unit
) {
    val scope = rememberCoroutineScope()
    var heightPx by remember { mutableIntStateOf(1) }
    var query by remember { mutableStateOf("") }
    val blurOn = LocalBlurOn.current
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }

    BackHandler(enabled = true) { scope.launch { drawer.settle(false, settings.animSpeed) } }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .graphicsLayer {
                val p = drawer.progress.value.coerceIn(0f, 1f)
                translationY = (1f - p) * heightPx
                alpha = (p * 1.6f).coerceIn(0f, 1f)
            }
            // Dengan blur Gaussian aktif, latar belakang jendela sudah diburamkan sistem, jadi lapisan gelap dibuat tipis.
            .background(Color.Black.copy(alpha = if (blurOn) 0.30f else 0.58f))
            .pointerInput(Unit) { } // menahan sentuhan agar tidak tembus ke beranda
    ) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            // Area atas: seret ke bawah untuk menutup.
            Column(
                Modifier
                    .fillMaxWidth()
                    .draggable(
                        orientation = Orientation.Vertical,
                        state = rememberDraggableState { d ->
                            scope.launch { drawer.drag(-d / (heightPx * 0.7f)) }
                        },
                        onDragStopped = { v ->
                            scope.launch {
                                drawer.settle(drawer.progress.value > 0.7f && v < 1200f, settings.animSpeed)
                            }
                        }
                    )
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier
                        .width(44.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color.White.copy(alpha = 0.5f))
                )
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("Cari aplikasi") },
                    shape = RoundedCornerShape(26.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color.White.copy(alpha = 0.7f),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                        cursorColor = Color.White,
                        focusedPlaceholderColor = Color.White.copy(alpha = 0.6f),
                        unfocusedPlaceholderColor = Color.White.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                )
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(settings.gridColumns),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                items(filtered, key = { it.key }) { app ->
                    // Dipusatkan di dalam sel supaya grid tidak condong ke kiri.
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        AppIconItem(
                            app = app,
                            vm = vm,
                            settings = settings,
                            showLabel = true,
                            menu = listOf(
                                "Tambah ke beranda" to { vm.addToHome(app) },
                                "Ubah ikon" to { onChangeIcon(app) },
                                "Reset ikon" to { vm.resetIcon(app) },
                                "Info aplikasi" to { vm.openInfo(app) },
                                "Copot pemasangan" to { vm.uninstall(app) }
                            ),
                            onOpen = { launchApp(app, it) }
                        )
                    }
                }
            }
        }
    }
}
