package com.zeruu.launcher.data

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent

/** Pembungkus AppWidgetHost: launcher menjadi "host" yang menampilkan widget aplikasi lain. */
class WidgetController(context: Context) {

    private val app = context.applicationContext
    private val manager: AppWidgetManager = AppWidgetManager.getInstance(app)
    private val host = AppWidgetHost(app, HOST_ID)

    fun startListening() { runCatching { host.startListening() } }

    fun stopListening() { runCatching { host.stopListening() } }

    fun providers(): List<AppWidgetProviderInfo> =
        runCatching { manager.installedProviders }.getOrDefault(emptyList())

    fun allocate(): Int = host.allocateAppWidgetId()

    fun tryBind(id: Int, info: AppWidgetProviderInfo): Boolean =
        runCatching { manager.bindAppWidgetIdIfAllowed(id, info.provider) }.getOrDefault(false)

    /** Dialog izin sistem, dipakai jika pengikatan langsung belum diizinkan. */
    fun bindIntent(id: Int, info: AppWidgetProviderInfo): Intent =
        Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)

    fun infoFor(id: Int): AppWidgetProviderInfo? = runCatching { manager.getAppWidgetInfo(id) }.getOrNull()

    fun needsConfigure(id: Int): Boolean = infoFor(id)?.configure != null

    fun configure(activity: Activity, id: Int) {
        host.startAppWidgetConfigureActivityForResult(activity, id, 0, REQ_CONFIGURE, null)
    }

    fun release(id: Int) { runCatching { host.deleteAppWidgetId(id) } }

    fun createView(context: Context, id: Int): AppWidgetHostView? {
        val info = infoFor(id) ?: return null
        return runCatching { host.createView(context, id, info) }.getOrNull()
    }

    companion object {
        const val HOST_ID = 0x5A3
        const val REQ_CONFIGURE = 0x2A
    }
}
