package com.zeruu.launcher.data

import android.content.ComponentName
import androidx.compose.runtime.Immutable

/** Ikon dimuat terpisah dan malas (lihat AppRepository.loadIcon), supaya daftar aplikasi langsung tampil. */
@Immutable
data class AppInfo(
    val label: String,
    val componentName: ComponentName
) {
    val packageName: String get() = componentName.packageName
    val key: String get() = componentName.flattenToString()
}
