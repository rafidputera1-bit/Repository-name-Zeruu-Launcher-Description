package com.zeruu.launcher.ui.lock

import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeruu.launcher.data.ZeruuSettings
import com.zeruu.launcher.ui.clock.LivingClockText
import com.zeruu.launcher.ui.clock.rememberNow
import kotlinx.coroutines.delay
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * AOD Zeruu: layar hitam dengan jam redup. Ini simulasi di dalam aplikasi (layar tetap menyala dengan
 * kecerahan sangat rendah selama launcher tampil); posisi digeser tiap menit agar piksel tidak terbakar.
 * Ketuk dua kali untuk keluar.
 */
@Composable
fun AodLayer(settings: ZeruuSettings, onExit: () -> Unit) {
    val context = LocalContext.current
    val now by rememberNow()
    val battery by produceState(initialValue = "") {
        while (true) {
            val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            value = if (level >= 0 && scale > 0) "${level * 100 / scale}%" else ""
            delay(60_000L)
        }
    }
    val dateFmt = DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())
    val dim = settings.copy(clockGlass = false, clockGlow = false, clockColor = 0xFFB4B4B4, clockStacked = false)
    val shiftX = ((now.minute * 37) % 41) - 20
    val shiftY = ((now.minute * 53) % 61) - 30

    BackHandler(enabled = true) { onExit() }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { onExit() }) }
    ) {
        Column(
            Modifier
                .align(Alignment.Center)
                .offset(shiftX.dp, shiftY.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LivingClockText(dim, 84f, now)
            if (settings.aodShowDate) {
                Text(now.format(dateFmt), color = Color(0xFF8A8A8A), fontSize = 15.sp)
            }
            if (settings.aodShowBattery && battery.isNotEmpty()) {
                Text(battery, color = Color(0xFF6E6E6E), fontSize = 14.sp)
            }
        }
    }
}
