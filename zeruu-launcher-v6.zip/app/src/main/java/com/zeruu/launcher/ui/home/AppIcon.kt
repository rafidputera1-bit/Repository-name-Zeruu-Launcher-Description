package com.zeruu.launcher.ui.home

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeruu.launcher.data.AppInfo
import com.zeruu.launcher.data.ZeruuSettings
import com.zeruu.launcher.ui.glass.glassPanel

/** Naik setiap ikon kustom berubah; dibaca sekali di HomeScreen lalu dibagikan ke semua ikon. */
val LocalIconVersion = compositionLocalOf { 0 }

internal fun iconShapeOf(settings: ZeruuSettings): Shape? = when (settings.iconShape) {
    1 -> CircleShape
    2 -> RoundedCornerShape(percent = 30)
    3 -> RoundedCornerShape(percent = 18)
    else -> null
}

private fun grayScale(scale: Float): ColorMatrix = ColorMatrix().apply {
    setToSaturation(0f)
    timesAssign(
        ColorMatrix(
            floatArrayOf(
                scale, 0f, 0f, 0f, 0f,
                0f, scale, 0f, 0f, 0f,
                0f, 0f, scale, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )
}

private fun iconFilter(theme: Int): ColorFilter? = when (theme) {
    2 -> ColorFilter.colorMatrix(grayScale(1.25f))
    3 -> ColorFilter.colorMatrix(grayScale(0.55f))
    4 -> ColorFilter.colorMatrix(grayScale(1.35f))
    else -> null
}

/**
 * Ikon aplikasi dengan tema: 0 asli, 1 liquid glass, 2 gelap, 3 terang, 4 monokrom.
 * Ikon dimuat malas, jadi tampilan tidak menunggu semua ikon selesai.
 */
@Composable
fun AppIconImage(
    app: AppInfo,
    vm: HomeViewModel,
    settings: ZeruuSettings,
    sizeScale: Float = 1f,
    sizeOverride: Float? = null
) {
    val version = LocalIconVersion.current
    val icon by produceState<ImageBitmap?>(initialValue = vm.cachedIcon(app), app.key, version) {
        value = vm.loadIcon(app) ?: value
    }
    val sizeDp = sizeOverride ?: (settings.iconSize * sizeScale)
    val theme = settings.iconTheme
    val userShape = iconShapeOf(settings)
    val plateShape: Shape = userShape ?: RoundedCornerShape(percent = 26)
    val bmp = icon

    if (theme == 0) {
        val mod = Modifier
            .size(sizeDp.dp)
            .then(if (userShape != null) Modifier.clip(userShape) else Modifier)
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = app.label, modifier = mod)
        } else {
            Box(mod.background(Color.White.copy(alpha = 0.14f), plateShape))
        }
    } else {
        val plate = when (theme) {
            1 -> Modifier.glassPanel(plateShape, 0.6f)
            2 -> Modifier.clip(plateShape).background(Color(0xFF181B26))
                .border(1.dp, Color.White.copy(alpha = 0.14f), plateShape)
            3 -> Modifier.clip(plateShape).background(Color(0xFFF1F3F8))
                .border(1.dp, Color.Black.copy(alpha = 0.08f), plateShape)
            else -> Modifier.clip(plateShape).background(Color(settings.accent).copy(alpha = 0.30f))
                .border(1.dp, Color.White.copy(alpha = 0.25f), plateShape)
        }
        Box(Modifier.size(sizeDp.dp).then(plate), contentAlignment = Alignment.Center) {
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = app.label,
                    colorFilter = iconFilter(theme),
                    modifier = Modifier.size((sizeDp * 0.74f).dp)
                )
            }
        }
    }
}

@Composable
private fun IconLabel(text: String, settings: ZeruuSettings) {
    Text(
        text = text,
        color = Color.White,
        fontSize = settings.labelSize.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .padding(top = 6.dp)
            .padding(horizontal = 4.dp)
    )
}

/**
 * Pembungkus perilaku ikon: ketuk membuka (dengan animasi zoom), tahan lama lalu seret untuk memindahkan,
 * atau tahan lama tanpa menggeser untuk menampilkan menu.
 * Jika [drag] null (drawer, dock, folder), tahan lama langsung menampilkan menu.
 */
@Composable
fun IconTile(
    entryId: String?,
    drag: DragState?,
    animSpeed: Float,
    menu: List<Pair<String, () -> Unit>>,
    onTap: (Rect) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var suppressTap by remember { mutableStateOf(false) }
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val currentOnTap by rememberUpdatedState(onTap)
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium * animSpeed.coerceIn(0.4f, 2.5f)
        ),
        label = "iconPress"
    )

    Box(modifier) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .onGloballyPositioned { bounds = it.boundsInRoot() }
                .pointerInput(entryId) {
                    detectTapGestures(
                        onPress = {
                            suppressTap = false
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onTap = { if (!suppressTap) currentOnTap(bounds) }
                    )
                }
                .pointerInput(entryId) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { off ->
                            suppressTap = true
                            if (drag != null && entryId != null) {
                                drag.begin(entryId, bounds.topLeft + off)
                            } else {
                                menuOpen = true
                            }
                        },
                        onDrag = { change, _ -> change.consume() },
                        onDragEnd = {
                            if (drag != null && entryId != null && !drag.lastMoved) menuOpen = true
                        },
                        onDragCancel = { }
                    )
                }
        ) {
            content()
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            menu.forEach { (title, action) ->
                DropdownMenuItem(
                    text = { Text(title) },
                    onClick = {
                        menuOpen = false
                        action()
                    }
                )
            }
        }
    }
}

@Composable
fun AppIconItem(
    app: AppInfo,
    vm: HomeViewModel,
    settings: ZeruuSettings,
    showLabel: Boolean,
    menu: List<Pair<String, () -> Unit>>,
    onOpen: (Rect) -> Unit,
    modifier: Modifier = Modifier,
    entryId: String? = null,
    drag: DragState? = null,
    sizeScale: Float = 1f
) {
    IconTile(entryId, drag, settings.animSpeed, menu, onOpen, modifier) {
        AppIconImage(app, vm, settings, sizeScale)
        if (showLabel && settings.showLabels) IconLabel(app.label, settings)
    }
}

/** Pratinjau folder: kotak kaca berisi hingga 9 ikon kecil (3 x 3). */
@Composable
fun FolderPreview(folder: FolderEntry, vm: HomeViewModel, settings: ZeruuSettings, sizeScale: Float = 1f) {
    val size = settings.iconSize * sizeScale
    val shape = iconShapeOf(settings) ?: RoundedCornerShape(percent = 26)
    val mini = (size - 14f) / 3f
    Box(Modifier.size(size.dp).glassPanel(shape, 0.5f), contentAlignment = Alignment.Center) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            folder.apps.take(9).chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    row.forEach { AppIconImage(it, vm, settings, sizeOverride = mini) }
                }
            }
        }
    }
}

@Composable
fun FolderIconItem(
    folder: FolderEntry,
    vm: HomeViewModel,
    settings: ZeruuSettings,
    drag: DragState?,
    menu: List<Pair<String, () -> Unit>>,
    onOpen: (Rect) -> Unit,
    modifier: Modifier = Modifier
) {
    IconTile(folder.id, drag, settings.animSpeed, menu, onOpen, modifier) {
        FolderPreview(folder, vm, settings)
        if (settings.showLabels) IconLabel(folder.folder.name, settings)
    }
}
