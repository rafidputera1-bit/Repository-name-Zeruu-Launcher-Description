# Aturan ProGuard/R8 (Tahap 1: minify nonaktif)
