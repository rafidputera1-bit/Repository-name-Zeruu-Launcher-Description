package com.zeruu.launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ZeruuAccent = Color(0xFF5CE1E6)
val ZeruuInk = Color(0xFF0B1020)

private val DarkColors = darkColorScheme(
    primary = ZeruuAccent,
    background = ZeruuInk,
    surface = Color(0xFF151B30),
    onSurface = Color.White
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF007C85),
    background = Color(0xFFF4F7FA),
    surface = Color.White,
    onSurface = ZeruuInk
)

@Composable
fun ZeruuTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
