package com.zeruu.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.zeruu.launcher.ui.home.HomeScreen
import com.zeruu.launcher.ui.home.HomeViewModel
import com.zeruu.launcher.ui.theme.ZeruuTheme

class MainActivity : ComponentActivity() {

    private val viewModel: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZeruuTheme {
                HomeScreen(viewModel)
            }
        }
    }
}
