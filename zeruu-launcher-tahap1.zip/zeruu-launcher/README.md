# Zeruu Launcher — Tahap 1

Fondasi launcher: MainActivity sebagai HOME, daftar aplikasi terinstal, buka aplikasi,
widget jam, grid ikon, dan dock sementara.

## Build lokal (Android Studio)
1. Buka folder ini di Android Studio (Koala atau lebih baru, JDK 17).
2. Tunggu Gradle sync. Android Studio akan membuat gradle wrapper sendiri.
3. Run ke perangkat, lalu tekan tombol Home dan pilih "Zeruu Launcher".

## Build via terminal
    gradle wrapper --gradle-version 8.7   # sekali saja
    ./gradlew assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk

## Build via GitHub Actions
Push ke GitHub (branch main). Unduh APK dari tab Actions > Artifacts.
