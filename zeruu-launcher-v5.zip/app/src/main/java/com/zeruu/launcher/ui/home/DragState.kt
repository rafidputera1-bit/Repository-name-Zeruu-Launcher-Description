package com.zeruu.launcher.ui.home

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset

/** Status seret-dan-lepas ikon di beranda. Posisi jari dilacak di tingkat layar (lihat HomeScreen). */
@Stable
class DragState {
    var id by mutableStateOf<String?>(null)
    var pointer by mutableStateOf(Offset.Zero)
    var start: Offset = Offset.Zero
    var moved by mutableStateOf(false)
    var lastMoved: Boolean = false

    fun begin(id: String, at: Offset) {
        this.id = id
        pointer = at
        start = at
        moved = false
        lastMoved = false
    }
}
