package com.zeruu.launcher.ui

import android.app.Activity
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.zeruu.launcher.ui.home.DrawerState
import com.zeruu.launcher.ui.home.HomeScreen
import com.zeruu.launcher.ui.home.HomeViewModel
import com.zeruu.launcher.ui.lock.LockLayer
import com.zeruu.launcher.ui.lock.UnlockState
import com.zeruu.launcher.ui.settings.SettingsHost
import com.zeruu.launcher.ui.settings.SettingsViewModel
import com.zeruu.launcher.ui.theme.LocalBlurOn
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun ZeruuRoot(
    homeViewModel: HomeViewModel,
    settingsViewModel: SettingsViewModel,
    unlockSignal: Int,
    resumeSignal: Int
) {
    val settings by settingsViewModel.settings.collectAsState()
    val scope = rememberCoroutineScope()
    val activity = LocalContext.current as? Activity
    val unlock = remember { UnlockState() }
    val drawer = remember { DrawerState() }
    val homeEnter = remember { Animatable(1f) }
    var showSettings by remember { mutableStateOf(false) }
    var systemMode by remember { mutableStateOf(false) }
    val blurSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    // Blur Gaussian sungguhan: sistem memburamkan wallpaper di belakang jendela saat drawer atau pengaturan terbuka.
    LaunchedEffect(settings.blurEnabled, settings.blurLevel) {
        val act = activity ?: return@LaunchedEffect
        if (!blurSupported) return@LaunchedEffect
        val enabled = settings.blurEnabled
        val maxPx = settings.blurLevel * 140f
        try {
            snapshotFlow {
                if (!enabled) 0f else max(drawer.progress.value.coerceIn(0f, 1f), if (showSettings) 1f else 0f)
            }.collect { p ->
                runCatching { act.window.setBackgroundBlurRadius((p * maxPx).roundToInt()) }
            }
        } finally {
            runCatching { act.window.setBackgroundBlurRadius(0) }
        }
    }

    // Setelah pengguna membuka kunci sistem: jam muncul besar di posisi lock lalu mengalir ke widget jam beranda.
    LaunchedEffect(unlockSignal) {
        if (unlockSignal > 0 && settings.systemUnlockAnim && !showSettings) {
            systemMode = true
            try {
                unlock.showLock()
                delay(140)
                unlock.animateTo(1f, settings.animSpeed, settings.animBounce)
            } finally {
                systemMode = false
                if (unlock.progress.value >= 1f) unlock.lockVisible = false
            }
        }
    }

    // Kembali ke beranda dari aplikasi lain: drawer menutup, beranda zoom masuk (gaya iOS).
    LaunchedEffect(resumeSignal) {
        if (resumeSignal > 0) {
            drawer.progress.snapTo(0f)
            if (!unlock.lockVisible) {
                homeEnter.snapTo(0f)
                homeEnter.animateTo(
                    1f,
                    spring(dampingRatio = 0.8f, stiffness = 300f * settings.animSpeed.coerceIn(0.4f, 2.5f))
                )
            }
        }
    }

    CompositionLocalProvider(LocalBlurOn provides (settings.blurEnabled && blurSupported)) {
        Box(Modifier.fillMaxSize()) {
            HomeScreen(
                viewModel = homeViewModel,
                settings = settings,
                progress = { unlock.progress.value },
                homeEnter = { homeEnter.value },
                drawer = drawer,
                clockHidden = unlock.lockVisible,
                onClockBounds = { unlock.homeClockBounds = it },
                onOpenSettings = { showSettings = true }
            )

            if (unlock.lockVisible) {
                LockLayer(
                    settings = settings,
                    unlock = unlock,
                    systemMode = systemMode,
                    onMoveCommit = { x, y -> settingsViewModel.update { it.copy(lockX = x, lockY = y) } }
                )
            }

            val ms = (320 / settings.animSpeed).toInt()
            AnimatedVisibility(
                visible = showSettings,
                enter = slideInVertically(tween(ms)) { it / 6 } + fadeIn(tween(ms)),
                exit = slideOutVertically(tween(ms)) { it / 6 } + fadeOut(tween(ms))
            ) {
                SettingsHost(
                    settings = settings,
                    onChange = { settingsViewModel.update(it) },
                    onClose = { showSettings = false },
                    onPreviewLock = {
                        showSettings = false
                        scope.launch { delay(280); unlock.showLock() }
                    },
                    onEditLockClock = {
                        showSettings = false
                        scope.launch { delay(280); unlock.showLock(); unlock.editMode = true }
                    }
                )
            }
        }
    }
}
