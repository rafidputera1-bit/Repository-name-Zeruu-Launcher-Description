package com.zeruu.launcher.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeruu.launcher.data.AppInfo
import com.zeruu.launcher.data.ZeruuSettings
import com.zeruu.launcher.ui.clock.LivingClockText
import com.zeruu.launcher.ui.clock.rememberNow
import com.zeruu.launcher.ui.glass.glassPanel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.absoluteValue
import kotlin.math.min
import kotlin.math.roundToInt

private const val OTHER_PAGE_ROWS = 6

private fun easeOutBack(t: Float, overshoot: Float): Float {
    val c3 = overshoot + 1f
    val x = t - 1f
    return 1f + c3 * x * x * x + overshoot * x * x
}

/** Halaman pertama memuat widget jam, jadi jumlah barisnya menyesuaikan tinggi jam. */
private fun firstPageRows(settings: ZeruuSettings): Int {
    val effective = settings.homeClockSize * (if (settings.clockStacked) 1.9f else 1f)
    return when {
        effective >= 140f -> 2
        effective >= 95f -> 3
        else -> 4
    }
}

/** Cubit (dua jari merapat) di mana saja pada beranda memicu [onPinch]. Tidak mengonsumsi sentuhan. */
private fun Modifier.pinchIn(onPinch: () -> Unit): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        var start = 0f
        var fired = false
        do {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val down = event.changes.filter { it.pressed }
            if (down.size >= 2 && !fired) {
                val d = (down[0].position - down[1].position).getDistance()
                if (start == 0f) start = d else if (d < start * 0.8f) {
                    fired = true
                    onPinch()
                }
            }
        } while (event.changes.any { it.pressed })
    }
}

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    settings: ZeruuSettings,
    progress: () -> Float,
    homeEnter: () -> Float,
    drawer: DrawerState,
    clockHidden: Boolean,
    onClockBounds: (Rect) -> Unit,
    onOpenSettings: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val iconVersion by viewModel.iconVersion.collectAsState()
    val now by rememberNow()
    val scope = rememberCoroutineScope()
    val view = LocalView.current
    val density = LocalDensity.current
    var heightPx by remember { mutableIntStateOf(1) }
    var widthPx by remember { mutableIntStateOf(1) }
    val drag = remember { DragState() }
    var openFolderId by remember { mutableStateOf<String?>(null) }
    val pageGrids = remember { mutableMapOf<Int, LayoutCoordinates>() }

    // Launcher tidak boleh keluar saat tombol kembali ditekan.
    BackHandler(enabled = true) { }

    val cols = settings.gridColumns
    val firstRows = firstPageRows(settings)
    LaunchedEffect(cols, firstRows, settings.homePages) {
        viewModel.setGrid(cols, firstRows, settings.homePages)
    }

    val pages = if (state.pages.isEmpty()) listOf(emptyList<HomeEntry>()) else state.pages
    val pagerState = rememberPagerState(pageCount = { pages.size })
    val drawerOpen by remember { derivedStateOf { drawer.progress.value > 0.02f } }
    val changeIcon = rememberIconPicker(viewModel)

    LaunchedEffect(clockHidden) { if (clockHidden) pagerState.scrollToPage(0) }

    val launchApp: (AppInfo, Rect) -> Unit = { app, r ->
        viewModel.launch(
            app, view,
            r.left.roundToInt(), r.top.roundToInt(), r.width.roundToInt(), r.height.roundToInt()
        )
    }
    val dockApps = remember(state.dock, settings.dockCount) { state.dock.take(settings.dockCount) }
    val a = settings.scrim

    // ----- Seret dan lepas -----
    fun resolveDrop(id: String) {
        val page = pagerState.currentPage
        val coords = pageGrids[page]?.takeIf { it.isAttached } ?: return
        val gb = coords.boundsInRoot()
        val p = drag.pointer
        if (!gb.contains(p)) return
        val rows = if (page == 0) firstRows else OTHER_PAGE_ROWS
        val cellW = gb.width / cols
        val cellH = gb.height / rows
        val col = ((p.x - gb.left) / cellW).toInt().coerceIn(0, cols - 1)
        val row = ((p.y - gb.top) / cellH).toInt().coerceIn(0, rows - 1)
        val idx = row * cols + col
        val target = pages.getOrNull(page)?.getOrNull(idx)
        val center = Offset(gb.left + (col + 0.5f) * cellW, gb.top + (row + 0.5f) * cellH)
        val near = (p - center).getDistance() < min(cellW, cellH) * 0.3f
        if (target != null && target.id != id && near && id.startsWith("a:")) {
            viewModel.dropOnto(id, target.id)
        } else {
            viewModel.moveEntry(id, page, idx)
        }
    }

    val release = {
        val id = drag.id
        if (id != null) {
            if (drag.moved) resolveDrop(id)
            drag.lastMoved = drag.moved
            drag.id = null
            drag.moved = false
        }
    }
    val currentRelease by rememberUpdatedState(release)

    // Menyeret ke tepi layar beberapa saat memindah halaman; di halaman terakhir, membuat halaman baru.
    val dragging = drag.id != null
    LaunchedEffect(dragging) {
        if (!dragging) return@LaunchedEffect
        val edgePx = with(density) { 44.dp.toPx() }
        var dwell = 0L
        var lastDir = 0
        while (drag.id != null) {
            val x = drag.pointer.x
            val dir = when {
                x < edgePx -> -1
                x > widthPx - edgePx -> 1
                else -> 0
            }
            dwell = if (dir != 0 && dir == lastDir) dwell + 80 else 0
            lastDir = dir
            if (dir != 0 && dwell >= 650) {
                dwell = 0
                val target = pagerState.currentPage + dir
                if (target in 0 until pagerState.pageCount) {
                    pagerState.animateScrollToPage(target)
                } else if (dir == 1) {
                    viewModel.addPage()
                    delay(150)
                    pagerState.animateScrollToPage(pagerState.pageCount - 1)
                }
            }
            delay(80)
        }
    }

    CompositionLocalProvider(LocalIconVersion provides iconVersion) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .onSizeChanged {
                    heightPx = it.height.coerceAtLeast(1)
                    widthPx = it.width.coerceAtLeast(1)
                }
                .pinchIn { onOpenSettings() }
                .pointerInput(Unit) {
                    // Melacak jari di tingkat layar, supaya seretan tetap jalan walau halaman asal sudah keluar layar.
                    val slop = 10.dp.toPx()
                    awaitPointerEventScope {
                        while (true) {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            if (drag.id != null) {
                                val c = ev.changes.firstOrNull()
                                if (c != null) {
                                    drag.pointer = c.position
                                    if (!drag.moved && (c.position - drag.start).getDistance() > slop) {
                                        drag.moved = true
                                    }
                                    if (!c.pressed) currentRelease()
                                }
                            }
                        }
                    }
                }
                .draggable(
                    state = rememberDraggableState { d ->
                        scope.launch { drawer.drag(-d / (heightPx * 0.7f)) }
                    },
                    orientation = Orientation.Vertical,
                    enabled = !clockHidden,
                    onDragStopped = { v ->
                        scope.launch {
                            drawer.settle(drawer.progress.value > 0.3f || v < -1200f, settings.animSpeed)
                        }
                    }
                )
        ) {
            // Redup wallpaper, muncul bertahap saat lock terbuka.
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = ((progress() - 0.1f) / 0.6f).coerceIn(0f, 1f) }
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = (a * 1.3f).coerceIn(0f, 1f)),
                                Color.Black.copy(alpha = (a * 0.4f).coerceIn(0f, 1f)),
                                Color.Black.copy(alpha = (a * 1.8f).coerceIn(0f, 1f))
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .graphicsLayer {
                        val t = ((progress() - 0.12f) / 0.6f).coerceIn(0f, 1f)
                        val d = drawer.progress.value.coerceIn(0f, 1f)
                        val e = homeEnter().coerceIn(0f, 1f)
                        // Gaya iOS: beranda sedikit mengecil saat drawer terbuka, dan zoom masuk saat kembali.
                        alpha = t * (1f - 0.65f * d) * (0.35f + 0.65f * e)
                        val sc = (0.95f + 0.05f * t) * (1f - 0.08f * d) * (1.10f - 0.10f * e)
                        scaleX = sc
                        scaleY = sc
                    }
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) { page ->
                    HomePage(
                        page = page,
                        items = pages.getOrNull(page) ?: emptyList(),
                        cols = cols,
                        rows = if (page == 0) firstRows else OTHER_PAGE_ROWS,
                        settings = settings,
                        vm = viewModel,
                        drag = drag,
                        pageGrids = pageGrids,
                        progress = progress,
                        pagerState = pagerState,
                        now = now,
                        clockHidden = clockHidden,
                        onClockBounds = onClockBounds,
                        launchApp = launchApp,
                        changeIcon = changeIcon,
                        onOpenFolder = { openFolderId = it },
                        onOpenSettings = onOpenSettings
                    )
                }

                if (pages.size > 1) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        repeat(pages.size) { i ->
                            val current = i == pagerState.currentPage
                            Box(
                                Modifier
                                    .padding(horizontal = 3.dp)
                                    .size(if (current) 8.dp else 6.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = if (current) 0.95f else 0.4f))
                            )
                        }
                    }
                }

                Dock(
                    apps = dockApps,
                    vm = viewModel,
                    settings = settings,
                    launchApp = launchApp,
                    changeIcon = changeIcon,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }

            // Hantu ikon yang sedang diseret.
            val dragId = drag.id
            if (dragId != null) {
                val entry = pages.flatten().firstOrNull { it.id == dragId }
                if (entry != null) {
                    val ghostPx = with(density) { (settings.iconSize * 1.2f).dp.toPx() }
                    Box(
                        Modifier
                            .offset {
                                IntOffset(
                                    (drag.pointer.x - ghostPx / 2f).roundToInt(),
                                    (drag.pointer.y - ghostPx / 2f).roundToInt()
                                )
                            }
                            .graphicsLayer { alpha = 0.92f; scaleX = 1.15f; scaleY = 1.15f }
                    ) {
                        when (entry) {
                            is AppEntry -> AppIconImage(entry.app, viewModel, settings, sizeScaleOf(entry.size))
                            is FolderEntry -> FolderPreview(entry, viewModel, settings)
                        }
                    }
                }
            }

            // Folder yang sedang dibuka.
            val folder = openFolderId?.let { id -> pages.flatten().firstOrNull { it.id == id } as? FolderEntry }
            LaunchedEffect(folder == null) { if (folder == null) openFolderId = null }
            if (folder != null) {
                FolderPopup(
                    folder = folder,
                    vm = viewModel,
                    settings = settings,
                    onClose = { openFolderId = null },
                    launchApp = launchApp
                )
            }

            if (drawerOpen) {
                AppDrawer(
                    apps = state.apps,
                    vm = viewModel,
                    settings = settings,
                    drawer = drawer,
                    launchApp = launchApp,
                    onChangeIcon = changeIcon
                )
            }
        }
    }
}

@Composable
private fun HomePage(
    page: Int,
    items: List<HomeEntry>,
    cols: Int,
    rows: Int,
    settings: ZeruuSettings,
    vm: HomeViewModel,
    drag: DragState,
    pageGrids: MutableMap<Int, LayoutCoordinates>,
    progress: () -> Float,
    pagerState: PagerState,
    now: LocalDateTime,
    clockHidden: Boolean,
    onClockBounds: (Rect) -> Unit,
    launchApp: (AppInfo, Rect) -> Unit,
    changeIcon: (AppInfo) -> Unit,
    onOpenFolder: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    val clockTop = settings.lockY < 0.5f
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                // Efek geser halaman gaya iOS: halaman di samping mengecil dan memudar.
                val off = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
                    .absoluteValue.coerceAtMost(1f)
                val s = 1f - 0.08f * off
                scaleX = s
                scaleY = s
                alpha = 1f - 0.5f * off
            }
    ) {
        // Area kosong: tahan lama membuka pengaturan Zeruu.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures(onLongPress = { onOpenSettings() }) }
        )
        Column(Modifier.fillMaxSize()) {
            if (page == 0) {
                HomeClockWidget(
                    settings = settings,
                    now = now,
                    hidden = clockHidden,
                    progress = progress,
                    onBounds = { r ->
                        if (pagerState.currentPage == 0 && pagerState.currentPageOffsetFraction == 0f) {
                            onClockBounds(r)
                        }
                    },
                    modifier = Modifier.padding(top = 12.dp)
                )
            }
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp)
                    .onGloballyPositioned { pageGrids[page] = it }
            ) {
                for (r in 0 until rows) {
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        for (c in 0 until cols) {
                            val entry = items.getOrNull(r * cols + c)
                            Box(
                                Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .graphicsLayer {
                                        alpha = if (entry != null && drag.id == entry.id) 0.2f else 1f
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (entry != null) {
                                    // Ikon masuk berkelompok per baris; arah dan urutan mengikuti posisi jam.
                                    val enter = Modifier.graphicsLayer {
                                        if (!settings.staggerIcons) return@graphicsLayer
                                        val p = progress()
                                        if (p >= 1f) return@graphicsLayer
                                        val order = if (clockTop) min(r, 7) else 7 - min(r, 7)
                                        val raw = ((p - 0.2f - order * 0.045f) / 0.5f).coerceIn(0f, 1f)
                                        val e = easeOutBack(raw, 0.6f + settings.animBounce * 1.6f)
                                        alpha = (raw * 1.8f).coerceIn(0f, 1f)
                                        val sc = 0.55f + 0.45f * e
                                        scaleX = sc
                                        scaleY = sc
                                        val dirY = if (clockTop) 1f else -1f
                                        translationY = dirY * 48.dp.toPx() * (1f - e)
                                        translationX = (0.5f - settings.lockX) * 36.dp.toPx() * (1f - e)
                                    }
                                    when (entry) {
                                        is AppEntry -> {
                                            val app = entry.app
                                            AppIconItem(
                                                app = app,
                                                vm = vm,
                                                settings = settings,
                                                showLabel = true,
                                                menu = listOf(
                                                    "Hapus dari beranda" to { vm.removeEntry(entry.id) },
                                                    "Ukuran: Kecil" to { vm.setSize(app.key, 0) },
                                                    "Ukuran: Normal" to { vm.setSize(app.key, 1) },
                                                    "Ukuran: Besar" to { vm.setSize(app.key, 2) },
                                                    "Ubah ikon" to { changeIcon(app) },
                                                    "Reset ikon" to { vm.resetIcon(app) },
                                                    "Info aplikasi" to { vm.openInfo(app) },
                                                    "Copot pemasangan" to { vm.uninstall(app) }
                                                ),
                                                onOpen = { launchApp(app, it) },
                                                modifier = enter,
                                                entryId = entry.id,
                                                drag = drag,
                                                sizeScale = sizeScaleOf(entry.size)
                                            )
                                        }
                                        is FolderEntry -> {
                                            FolderIconItem(
                                                folder = entry,
                                                vm = vm,
                                                settings = settings,
                                                drag = drag,
                                                menu = listOf(
                                                    "Buka folder" to { onOpenFolder(entry.id) },
                                                    "Bubarkan folder" to { vm.removeEntry(entry.id) }
                                                ),
                                                onOpen = { onOpenFolder(entry.id) },
                                                modifier = enter
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Isi folder: nama bisa diganti, ikon bisa dibuka atau dikeluarkan dari folder. */
@Composable
private fun FolderPopup(
    folder: FolderEntry,
    vm: HomeViewModel,
    settings: ZeruuSettings,
    onClose: () -> Unit,
    launchApp: (AppInfo, Rect) -> Unit
) {
    BackHandler(enabled = true) { onClose() }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .padding(24.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(Color(0xE61B1F2E))
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = folder.folder.name,
                onValueChange = { vm.renameFolder(folder.folder.id, it) },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color.White.copy(alpha = 0.7f),
                    unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                    cursorColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.size(16.dp))
            Column(
                Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                folder.apps.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { app ->
                            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                AppIconItem(
                                    app = app,
                                    vm = vm,
                                    settings = settings,
                                    showLabel = true,
                                    menu = listOf(
                                        "Keluarkan dari folder" to { vm.removeFromFolder(folder.folder.id, app.key) },
                                        "Info aplikasi" to { vm.openInfo(app) }
                                    ),
                                    onOpen = { launchApp(app, it) }
                                )
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

/** Widget jam di beranda (gaya Flux): titik tujuan animasi morph dari lock screen. */
@Composable
private fun HomeClockWidget(
    settings: ZeruuSettings,
    now: LocalDateTime,
    hidden: Boolean,
    progress: () -> Float,
    onBounds: (Rect) -> Unit,
    modifier: Modifier = Modifier
) {
    val align = when (settings.homeClockAlign) {
        1 -> Alignment.CenterHorizontally
        2 -> Alignment.End
        else -> Alignment.Start
    }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()) }
    val dateText: @Composable () -> Unit = {
        if (settings.showDate) {
            Text(
                text = now.format(dateFormatter),
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 16.sp,
                style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.3f), Offset.Zero, 6f)),
                modifier = Modifier.graphicsLayer {
                    alpha = ((progress() - 0.5f) / 0.5f).coerceIn(0f, 1f)
                }
            )
        }
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
        horizontalAlignment = align
    ) {
        if (settings.clockDatePos == 0) dateText()
        Box(
            Modifier
                .onGloballyPositioned { onBounds(it.boundsInRoot()) }
                .graphicsLayer { alpha = if (hidden) 0f else 1f }
        ) {
            LivingClockText(settings, settings.homeClockSize, now)
        }
        if (settings.clockDatePos != 0) dateText()
    }
}

@Composable
private fun Dock(
    apps: List<AppInfo>,
    vm: HomeViewModel,
    settings: ZeruuSettings,
    launchApp: (AppInfo, Rect) -> Unit,
    changeIcon: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!settings.dockEnabled || apps.isEmpty()) return
    val shape = RoundedCornerShape(settings.dockRadius.dp)
    val look = if (settings.dockGlass) {
        Modifier.glassPanel(shape, settings.dockGlassLevel)
    } else {
        Modifier.background(Color.White.copy(alpha = settings.dockAlpha), shape)
    }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .then(look)
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        apps.forEach { app ->
            AppIconItem(
                app = app,
                vm = vm,
                settings = settings,
                showLabel = false,
                menu = listOf(
                    "Ubah ikon" to { changeIcon(app) },
                    "Reset ikon" to { vm.resetIcon(app) },
                    "Info aplikasi" to { vm.openInfo(app) }
                ),
                onOpen = { launchApp(app, it) }
            )
        }
    }
}
