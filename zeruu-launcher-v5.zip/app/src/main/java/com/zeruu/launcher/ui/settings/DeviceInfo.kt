package com.zeruu.launcher.ui.settings

import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Display
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

data class DeviceInfoData(
    val osName: String,
    val osSub: String,
    val deviceName: String,
    val storageText: String,
    val storageFraction: Float,
    val model: String,
    val build: String,
    val processor: String,
    val ram: String,
    val screen: String,
    val security: String,
    val kernel: String
)

/** Membaca info ponsel yang sedang dipakai. Semua nilai berasal dari API Android resmi, tanpa izin khusus. */
suspend fun readDeviceInfo(context: Context): DeviceInfoData = withContext(Dispatchers.IO) {
    val manufacturer = Build.MANUFACTURER.lowercase(Locale.ROOT)
    val colorOs = if (manufacturer in listOf("oppo", "oneplus", "realme")) {
        Regex("_(\\d+\\.\\d+)").find(Build.DISPLAY)?.groupValues?.get(1)
    } else null
    val osName = if (colorOs != null) "ColorOS $colorOs" else "Android ${Build.VERSION.RELEASE}"
    val osSub = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

    val deviceName = runCatching {
        Settings.Global.getString(context.contentResolver, "device_name")
    }.getOrNull() ?: Build.MODEL

    // Penyimpanan: kapasitas dibulatkan ke ukuran pemasaran (64, 128, 256 GB, dst).
    val stat = StatFs(Environment.getDataDirectory().path)
    val totalGb = stat.blockCountLong * stat.blockSizeLong / 1e9
    val freeGb = stat.availableBlocksLong * stat.blockSizeLong / 1e9
    val marketing = listOf(16, 32, 64, 128, 256, 512, 1024, 2048).firstOrNull { it >= totalGb }
        ?: totalGb.roundToInt()
    val usedGb = (marketing - freeGb).coerceAtLeast(0.0)
    val storageText = String.format(Locale.getDefault(), "%.1f GB / %d GB", usedGb, marketing)
    val fraction = (usedGb / marketing).toFloat().coerceIn(0f, 1f)

    // RAM dibulatkan ke ukuran pemasaran.
    val am = context.getSystemService(ActivityManager::class.java)
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    val ramGb = mi.totalMem / 1073741824.0
    val ramMarketing = listOf(1, 2, 3, 4, 6, 8, 10, 12, 16, 24, 32).firstOrNull { it >= ramGb }
        ?: ramGb.roundToInt()

    val soc = if (Build.VERSION.SDK_INT >= 31) {
        listOf(Build.SOC_MANUFACTURER, Build.SOC_MODEL)
            .filter { it.isNotBlank() && it != "unknown" }
            .joinToString(" ")
    } else ""
    val processor = (if (soc.isNotBlank()) soc else Build.HARDWARE) +
        " (${Runtime.getRuntime().availableProcessors()} inti)"

    val dm = context.resources.displayMetrics
    val hz = context.getSystemService(DisplayManager::class.java)
        ?.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate?.roundToInt()
    val screen = "${dm.widthPixels} x ${dm.heightPixels}" + (if (hz != null) " - $hz Hz" else "")

    DeviceInfoData(
        osName = osName,
        osSub = osSub,
        deviceName = deviceName,
        storageText = storageText,
        storageFraction = fraction,
        model = Build.MODEL,
        build = Build.DISPLAY,
        processor = processor,
        ram = "$ramMarketing GB",
        screen = screen,
        security = Build.VERSION.SECURITY_PATCH,
        kernel = System.getProperty("os.version") ?: ""
    )
}


fun aboutBackgroundFile(context: Context) = File(context.filesDir, "about_bg.jpg")

/** Menyimpan gambar pilihan pengguna sebagai latar halaman Tentang perangkat (dikecilkan agar hemat memori). */
suspend fun saveAboutBackground(context: Context, uri: Uri): Boolean = withContext(Dispatchers.IO) {
    try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1280 || bounds.outHeight / sample > 1280) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return@withContext false
        aboutBackgroundFile(context).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        true
    } catch (e: Exception) {
        false
    }
}
