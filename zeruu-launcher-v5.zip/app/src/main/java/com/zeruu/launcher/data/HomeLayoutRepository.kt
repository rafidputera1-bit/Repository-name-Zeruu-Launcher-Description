package com.zeruu.launcher.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class HomeLayoutRepository(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("zeruu_layout", Context.MODE_PRIVATE)

    fun hasLayout(): Boolean = prefs.contains("layout") || prefs.contains("home")

    fun load(): HomeLayout {
        val raw = prefs.getString("layout", null)
        if (raw != null) return runCatching { decode(raw) }.getOrElse { HomeLayout() }
        // Migrasi dari versi 0.4.x (daftar datar).
        fun split(s: String?) = if (s.isNullOrEmpty()) emptyList() else s.split("\n")
        return HomeLayout(
            pages = listOf(split(prefs.getString("home", "")).map { "a:$it" }),
            dock = split(prefs.getString("dock", "")),
            seen = prefs.getStringSet("seen", emptySet())?.toSet() ?: emptySet()
        )
    }

    fun save(layout: HomeLayout) {
        prefs.edit().putString("layout", encode(layout).toString()).apply()
    }

    private fun encode(l: HomeLayout): JSONObject = JSONObject().apply {
        put("pages", JSONArray(l.pages.map { JSONArray(it) }))
        put("dock", JSONArray(l.dock))
        put("seen", JSONArray(l.seen.toList()))
        put("folders", JSONObject().apply {
            l.folders.forEach { (id, f) ->
                put(id, JSONObject().put("name", f.name).put("apps", JSONArray(f.apps)))
            }
        })
        put("sizes", JSONObject().apply { l.sizes.forEach { (k, v) -> put(k, v) } })
    }

    private fun decode(raw: String): HomeLayout {
        val o = JSONObject(raw)
        fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }
        val pagesArr = o.getJSONArray("pages")
        val pages = (0 until pagesArr.length()).map { pagesArr.getJSONArray(it).strings() }
        val folders = mutableMapOf<String, FolderData>()
        o.optJSONObject("folders")?.let { fo ->
            fo.keys().forEach { id ->
                val f = fo.getJSONObject(id)
                folders[id] = FolderData(id, f.optString("name", "Folder"), f.getJSONArray("apps").strings())
            }
        }
        val sizes = mutableMapOf<String, Int>()
        o.optJSONObject("sizes")?.let { so -> so.keys().forEach { k -> sizes[k] = so.getInt(k) } }
        return HomeLayout(
            pages = pages.ifEmpty { listOf(emptyList()) },
            dock = o.getJSONArray("dock").strings(),
            folders = folders,
            sizes = sizes,
            seen = o.getJSONArray("seen").strings().toSet()
        )
    }
}
