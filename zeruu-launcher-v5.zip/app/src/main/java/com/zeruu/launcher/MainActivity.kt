package com.zeruu.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import com.zeruu.launcher.ui.ZeruuRoot
import com.zeruu.launcher.ui.home.HomeViewModel
import com.zeruu.launcher.ui.settings.SettingsViewModel
import com.zeruu.launcher.ui.theme.ZeruuTheme

class MainActivity : ComponentActivity() {

    private val homeViewModel: HomeViewModel by viewModels()
    private val settingsViewModel: SettingsViewModel by viewModels()

    /** Naik satu kali setiap ada pembukaan kunci yang perlu diberi animasi jam. */
    private val unlockSignal = mutableIntStateOf(0)
    /** Naik setiap launcher kembali tampil (misalnya setelah menutup aplikasi lain). */
    private val resumeSignal = mutableIntStateOf(0)
    private var lastUnlockAt = 0L

    private val userPresentReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                unlockSignal.intValue++
            } else {
                lastUnlockAt = SystemClock.elapsedRealtime()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ContextCompat.registerReceiver(
            this,
            userPresentReceiver,
            IntentFilter(Intent.ACTION_USER_PRESENT),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        setContent {
            val settings by settingsViewModel.settings.collectAsState()
            ZeruuTheme(settings) {
                ZeruuRoot(homeViewModel, settingsViewModel, unlockSignal.intValue, resumeSignal.intValue)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (lastUnlockAt != 0L && SystemClock.elapsedRealtime() - lastUnlockAt < 3000L) {
            unlockSignal.intValue++
        } else {
            resumeSignal.intValue++
        }
        lastUnlockAt = 0L
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(userPresentReceiver) }
        super.onDestroy()
    }
}
