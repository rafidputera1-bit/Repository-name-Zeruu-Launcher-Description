package com.zeruu.launcher.ui.lock

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import com.zeruu.launcher.ui.glass.glassPanel
import com.zeruu.launcher.data.ZeruuSettings
import com.zeruu.launcher.ui.clock.LivingClockText
import com.zeruu.launcher.ui.clock.rememberNow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.max

/**
 * Lock screen simulasi Zeruu (di dalam aplikasi, bukan keyguard sistem).
 * Jam di sini adalah jam yang SAMA yang bergerak (morph) menjadi widget jam di beranda.
 * Jam digambar pada ukuran terbesar lalu diskalakan, jadi tetap tajam saat membesar maupun mengecil.
 */
@Composable
fun LockLayer(
    settings: ZeruuSettings,
    unlock: UnlockState,
    systemMode: Boolean,
    onMoveCommit: (Float, Float) -> Unit
) {
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val context = LocalContext.current
    val now by rememberNow()
    var screen by remember { mutableStateOf(IntSize.Zero) }
    var clockSize by remember { mutableStateOf(IntSize.Zero) }
    var dateSize by remember { mutableStateOf(IntSize.Zero) }
    var posX by remember(settings.lockX) { mutableFloatStateOf(settings.lockX) }
    var posY by remember(settings.lockY) { mutableFloatStateOf(settings.lockY) }
    val edit = unlock.editMode && !systemMode
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()) }

    val baseSp = max(settings.lockClockSize, settings.homeClockSize)
    val s0 = settings.lockClockSize / baseSp   // skala di lock screen
    val s1 = settings.homeClockSize / baseSp   // skala di beranda
    val visibleW = clockSize.width * s0
    val visibleH = clockSize.height * s0

    val battery by produceState(initialValue = "") {
        while (true) {
            value = readBattery(context)
            delay(30_000L)
        }
    }
    val pulse by rememberInfiniteTransition(label = "hint").animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "hintPulse"
    )

    BackHandler(enabled = edit) { unlock.editMode = false }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onSizeChanged { screen = it }
            .draggable(
                state = rememberDraggableState { d ->
                    scope.launch {
                        unlock.drag(-d / (screen.height.coerceAtLeast(1) * 0.55f))
                    }
                },
                orientation = Orientation.Vertical,
                enabled = !edit && !systemMode,
                onDragStopped = { velocity ->
                    scope.launch {
                        val open = unlock.progress.value > 0.35f || velocity < -1400f
                        unlock.animateTo(if (open) 1f else 0f, settings.animSpeed, settings.animBounce)
                    }
                }
            )
            .pointerInput(systemMode) {
                if (!systemMode) {
                    detectTapGestures(onLongPress = { unlock.editMode = !unlock.editMode })
                }
            }
    ) {
        // Redup wallpaper, memudar saat membuka kunci.
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = (1f - unlock.progress.value).coerceIn(0f, 1f) }
                .background(Color.Black.copy(alpha = 0.28f))
        )

        // Tanggal di atas atau di bawah jam.
        if (settings.showDate) {
            Box(
                Modifier
                    .width(with(density) { visibleW.toDp() })
                    .onSizeChanged { dateSize = it }
                    .graphicsLayer {
                        alpha = (1f - unlock.progress.value * 2.2f).coerceIn(0f, 1f)
                        val lx = posX * (screen.width - visibleW).coerceAtLeast(0f)
                        val ly = posY * (screen.height - visibleH).coerceAtLeast(0f)
                        translationX = lx
                        translationY = if (settings.clockDatePos == 0) {
                            (ly - dateSize.height - 4.dp.toPx()).coerceAtLeast(0f)
                        } else {
                            ly + visibleH + 4.dp.toPx()
                        }
                    }
            ) {
                Text(
                    text = now.format(dateFormatter),
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = 18.sp,
                    maxLines = 1,
                    softWrap = false,
                    textAlign = TextAlign.Center,
                    style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.35f), Offset.Zero, 8f)),
                    modifier = Modifier.wrapContentWidth(Alignment.CenterHorizontally, unbounded = true)
                )
            }
        }

        // Jam yang bergerak: dari posisi lock ke posisi widget jam di beranda.
        Box(
            Modifier
                .onSizeChanged { clockSize = it }
                .graphicsLayer {
                    val p = unlock.progress.value
                    val lx = posX * (screen.width - visibleW).coerceAtLeast(0f)
                    val ly = posY * (screen.height - visibleH).coerceAtLeast(0f)
                    val hb = unlock.homeClockBounds
                    transformOrigin = TransformOrigin(0f, 0f)
                    translationX = lerp(lx, hb.left, p)
                    translationY = lerp(ly, hb.top, p)
                    val s = lerp(s0, s1, p)
                    scaleX = s
                    scaleY = s
                }
                .pointerInput(edit) {
                    if (edit) {
                        detectDragGestures(onDragEnd = { onMoveCommit(posX, posY) }) { change, drag ->
                            change.consume()
                            val freeW = (screen.width - visibleW).coerceAtLeast(1f)
                            val freeH = (screen.height - visibleH).coerceAtLeast(1f)
                            posX = (posX + drag.x / freeW).coerceIn(0f, 1f)
                            posY = (posY + drag.y / freeH).coerceIn(0f, 1f)
                        }
                    }
                }
        ) {
            LivingClockText(settings, baseSp, now)
        }

        if (!systemMode) {
            if (settings.showBattery && battery.isNotEmpty()) {
                Text(
                    text = battery,
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 13.sp,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .statusBarsPadding()
                        .padding(top = 12.dp)
                        .graphicsLayer { alpha = (1f - unlock.progress.value * 2.2f).coerceIn(0f, 1f) }
                )
            }
            if (!edit) {
                Text(
                    text = "Geser ke atas untuk membuka",
                    color = Color.White,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 36.dp)
                        .graphicsLayer {
                            alpha = (1f - unlock.progress.value * 2.2f).coerceIn(0f, 1f) * pulse
                        }
                        .clickable {
                            scope.launch { unlock.animateTo(1f, settings.animSpeed, settings.animBounce) }
                        }
                        .padding(12.dp)
                )
            }
        }

        if (!systemMode && !edit) {
            LockExtras(settings, unlock, Modifier.align(Alignment.BottomCenter))
        }

        if (edit) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                color = Color(0xE6101420)
            ) {
                Column(
                    Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Seret jam untuk memindahkan", color = Color.White, fontSize = 14.sp)
                    Row {
                        TextButton(onClick = { posX = 0.5f; posY = 0.12f; onMoveCommit(posX, posY) }) { Text("Atas") }
                        TextButton(onClick = { posX = 0.5f; posY = 0.42f; onMoveCommit(posX, posY) }) { Text("Tengah") }
                        TextButton(onClick = { posX = 0.5f; posY = 0.72f; onMoveCommit(posX, posY) }) { Text("Bawah") }
                    }
                    Button(onClick = { unlock.editMode = false }) { Text("Selesai") }
                }
            }
        }
    }
}

private fun readBattery(context: Context): String {
    val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return ""
    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    if (level < 0 || scale <= 0) return ""
    val pct = level * 100 / scale
    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    return if (charging) "Mengisi daya  $pct%" else "$pct%"
}


private data class LockStats(
    val battery: Int = 0,
    val charging: Boolean = false,
    val storage: Int = 0,
    val ram: Int = 0
)

private data class LockCard(val title: String, val value: String, val fraction: Float?)

private fun readLockStats(context: Context): LockStats {
    val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    val battery = if (level >= 0 && scale > 0) level * 100 / scale else 0
    val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    val stat = StatFs(Environment.getDataDirectory().path)
    val total = stat.blockCountLong * stat.blockSizeLong
    val free = stat.availableBlocksLong * stat.blockSizeLong
    val storage = if (total > 0) ((total - free) * 100 / total).toInt() else 0
    val mi = ActivityManager.MemoryInfo()
    context.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
    val ram = if (mi.totalMem > 0) (((mi.totalMem - mi.availMem) * 100) / mi.totalMem).toInt() else 0
    return LockStats(battery, charging, storage, ram)
}

/** Seni teks (gaya Flux) dan widget bawaan di lock screen: baterai, penyimpanan, RAM, tanggal, catatan. */
@Composable
private fun LockExtras(settings: ZeruuSettings, unlock: UnlockState, modifier: Modifier) {
    val context = LocalContext.current
    val now by rememberNow()
    val stats by produceState(initialValue = LockStats()) {
        while (true) {
            value = readLockStats(context)
            delay(30_000L)
        }
    }
    val dayFmt = remember { DateTimeFormatter.ofPattern("EEEE", Locale.getDefault()) }
    val dateFmt = remember { DateTimeFormatter.ofPattern("d MMM", Locale.getDefault()) }
    val cards = buildList {
        if (settings.lockWidgets and 1 != 0) {
            add(LockCard("Baterai", if (stats.charging) "${stats.battery}% mengisi" else "${stats.battery}%", stats.battery / 100f))
        }
        if (settings.lockWidgets and 2 != 0) add(LockCard("Penyimpanan", "${stats.storage}% terpakai", stats.storage / 100f))
        if (settings.lockWidgets and 4 != 0) add(LockCard("RAM", "${stats.ram}% terpakai", stats.ram / 100f))
        if (settings.lockWidgets and 8 != 0) add(LockCard(now.format(dayFmt), now.format(dateFmt), null))
        if (settings.lockWidgets and 16 != 0) {
            add(LockCard("Catatan", settings.lockNote.ifBlank { "Isi di pengaturan" }, null))
        }
    }
    val shape = RoundedCornerShape(22.dp)

    Column(
        modifier
            .navigationBarsPadding()
            .padding(bottom = 88.dp)
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .graphicsLayer { alpha = (1f - unlock.progress.value * 2.2f).coerceIn(0f, 1f) },
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (settings.lockWordArt && settings.lockWordText.isNotBlank()) {
            Text(
                text = settings.lockWordText,
                fontSize = 44.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Italic,
                textAlign = TextAlign.Center,
                style = TextStyle(
                    brush = Brush.verticalGradient(
                        0f to Color.White.copy(alpha = 0.95f),
                        1f to Color.White.copy(alpha = 0.5f)
                    ),
                    shadow = Shadow(Color.Black.copy(alpha = 0.3f), Offset.Zero, 12f)
                ),
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }
        cards.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { c ->
                    Column(
                        Modifier
                            .weight(1f)
                            .glassPanel(shape, 0.6f)
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Text(c.title, color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
                        Text(c.value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                        if (c.fraction != null) {
                            Spacer(Modifier.height(6.dp))
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(Color.White.copy(alpha = 0.2f))
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(c.fraction.coerceIn(0.02f, 1f))
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(Color.White.copy(alpha = 0.9f))
                                )
                            }
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
