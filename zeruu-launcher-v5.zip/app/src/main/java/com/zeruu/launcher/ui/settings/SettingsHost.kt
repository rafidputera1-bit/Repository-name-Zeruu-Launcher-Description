package com.zeruu.launcher.ui.settings

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.zeruu.launcher.data.ZeruuSettings
import com.zeruu.launcher.ui.theme.LocalBlurOn

/**
 * Setelan Zeruu. Halaman utama: Your Theme (terpisah dari yang lain), Animasi, Tentang perangkat.
 * Terbuka dengan mencubit atau menahan lama di beranda.
 */
@Composable
fun SettingsHost(
    settings: ZeruuSettings,
    onChange: ((ZeruuSettings) -> ZeruuSettings) -> Unit,
    onClose: () -> Unit,
    onPreviewLock: () -> Unit,
    onEditLockClock: () -> Unit
) {
    var route by remember { mutableStateOf("home") }
    BackHandler(enabled = true) {
        when (route) {
            "lock", "homecfg" -> route = "theme"
            "theme", "anim", "about" -> route = "home"
            else -> onClose()
        }
    }

    Crossfade(targetState = route, label = "settingsRoute") { r ->
        when (r) {
            "theme" -> YourThemePage(
                settings = settings,
                onChange = onChange,
                onBack = { route = "home" },
                onOpenLock = { route = "lock" },
                onOpenHome = { route = "homecfg" }
            )
            "lock" -> LockStylePage(
                settings = settings,
                onChange = onChange,
                onBack = { route = "theme" },
                onPreviewLock = onPreviewLock,
                onEditLockClock = onEditLockClock
            )
            "homecfg" -> HomeStylePage(settings = settings, onChange = onChange, onBack = { route = "theme" })
            "anim" -> AnimationPage(settings = settings, onChange = onChange, onBack = { route = "home" })
            "about" -> AboutScreen(settings = settings, onChange = onChange, onBack = { route = "home" })
            else -> SettingsHome(onOpen = { route = it }, onClose = onClose)
        }
    }
}

@Composable
private fun SettingsHome(onOpen: (String) -> Unit, onClose: () -> Unit) {
    val blur = LocalBlurOn.current
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background.copy(alpha = if (blur) 0.70f else 0.94f),
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
                Spacer(Modifier.weight(1f))
                Button(onClick = onClose) { Text("Selesai") }
            }
            Text(
                "Setelan Zeruu",
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.padding(start = 24.dp, bottom = 16.dp)
            )
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Your Theme berdiri sendiri, terpisah dari menu lain.
                Card(colors = cardColors()) {
                    NavRow("Y", "Your Theme", "Kustom lock screen dan kustom beranda") { onOpen("theme") }
                }
                Card(colors = cardColors()) {
                    Column {
                        NavRow("A", "Animasi", "Kecepatan, pantulan, dan animasi membuka kunci") { onOpen("anim") }
                        HorizontalDivider(Modifier.padding(start = 72.dp))
                        NavRow("i", "Tentang perangkat", Build.MODEL) { onOpen("about") }
                    }
                }
            }
        }
    }
}
