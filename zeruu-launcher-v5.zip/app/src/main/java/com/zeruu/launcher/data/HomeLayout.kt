package com.zeruu.launcher.data

data class FolderData(val id: String, val name: String, val apps: List<String>)

/**
 * Susunan beranda. Setiap halaman berisi id entri berurutan: "a:<komponen>" untuk aplikasi
 * atau "f:<id>" untuk folder. Posisi sel dihitung dari urutan (gaya iOS, tanpa celah).
 */
data class HomeLayout(
    val pages: List<List<String>> = listOf(emptyList()),
    val dock: List<String> = emptyList(),
    val folders: Map<String, FolderData> = emptyMap(),
    val sizes: Map<String, Int> = emptyMap(),   // kunci aplikasi -> 0 kecil, 1 normal, 2 besar
    val seen: Set<String> = emptySet()
)
