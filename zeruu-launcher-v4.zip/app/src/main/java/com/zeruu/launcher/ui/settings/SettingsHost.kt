package com.zeruu.launcher.ui.settings

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.zeruu.launcher.data.ZeruuSettings

/**
 * Setelan Zeruu: halaman utama berupa daftar kategori (seperti Pengaturan sistem).
 * Terbuka dengan mencubit atau menahan lama di beranda.
 */
@Composable
fun SettingsHost(
    settings: ZeruuSettings,
    onChange: ((ZeruuSettings) -> ZeruuSettings) -> Unit,
    onClose: () -> Unit,
    onPreviewLock: () -> Unit,
    onEditLockClock: () -> Unit
) {
    var route by remember { mutableStateOf("home") }
    BackHandler(enabled = true) { if (route != "home") route = "home" else onClose() }

    Crossfade(targetState = route, label = "settingsRoute") { r ->
        when (r) {
            "style" -> StylePage(
                settings = settings,
                onChange = onChange,
                onClose = { route = "home" },
                onPreviewLock = onPreviewLock,
                onEditLockClock = onEditLockClock
            )
            "anim" -> AnimationPage(settings = settings, onChange = onChange, onBack = { route = "home" })
            "about" -> AboutScreen(onBack = { route = "home" })
            else -> SettingsHome(onOpen = { route = it }, onClose = onClose)
        }
    }
}

@Composable
private fun SettingsHome(onOpen: (String) -> Unit, onClose: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.97f)
    ) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
                Spacer(Modifier.weight(1f))
                Button(onClick = onClose) { Text("Selesai") }
            }
            Text(
                "Setelan Zeruu",
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.padding(start = 24.dp, bottom = 16.dp)
            )
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column {
                        NavRow("G", "Gaya (Tema Anda)", "Layar kunci, beranda, jam, ikon, dock, dan tema") { onOpen("style") }
                        HorizontalDivider(Modifier.padding(start = 72.dp))
                        NavRow("A", "Animasi", "Kecepatan, pantulan, dan animasi membuka kunci") { onOpen("anim") }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    NavRow("i", "Tentang perangkat", Build.MODEL) { onOpen("about") }
                }
            }
        }
    }
}

@Composable
private fun NavRow(icon: String, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
        ) { Text(icon, style = MaterialTheme.typography.titleMedium) }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
            )
        }
        Text(">", style = MaterialTheme.typography.titleLarge)
    }
}
