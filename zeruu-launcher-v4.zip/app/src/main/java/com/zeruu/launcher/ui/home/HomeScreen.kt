package com.zeruu.launcher.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeruu.launcher.data.AppInfo
import com.zeruu.launcher.data.ZeruuSettings
import com.zeruu.launcher.ui.clock.LivingClockText
import com.zeruu.launcher.ui.clock.rememberNow
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.absoluteValue
import kotlin.math.min
import kotlin.math.roundToInt

private const val OTHER_PAGE_ROWS = 6

private fun easeOutBack(t: Float, overshoot: Float): Float {
    val c3 = overshoot + 1f
    val x = t - 1f
    return 1f + c3 * x * x * x + overshoot * x * x
}

/** Halaman pertama memuat widget jam, jadi jumlah barisnya menyesuaikan tinggi jam. */
private fun firstPageRows(settings: ZeruuSettings): Int {
    val effective = settings.homeClockSize * (if (settings.clockStacked) 1.9f else 1f)
    return when {
        effective >= 140f -> 2
        effective >= 95f -> 3
        else -> 4
    }
}

private fun chunkPages(items: List<AppInfo>, cols: Int, firstRows: Int): List<List<AppInfo>> {
    val pages = mutableListOf<List<AppInfo>>()
    var i = 0
    while (i < items.size || pages.isEmpty()) {
        val cap = cols * (if (pages.isEmpty()) firstRows else OTHER_PAGE_ROWS)
        pages += items.subList(i, min(items.size, i + cap))
        i += cap
    }
    return pages
}

/** Cubit (dua jari merapat) di mana saja pada beranda memicu [onPinch]. Tidak mengonsumsi sentuhan. */
private fun Modifier.pinchIn(onPinch: () -> Unit): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        var start = 0f
        var fired = false
        do {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val down = event.changes.filter { it.pressed }
            if (down.size >= 2 && !fired) {
                val d = (down[0].position - down[1].position).getDistance()
                if (start == 0f) start = d else if (d < start * 0.8f) {
                    fired = true
                    onPinch()
                }
            }
        } while (event.changes.any { it.pressed })
    }
}

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    settings: ZeruuSettings,
    progress: () -> Float,
    homeEnter: () -> Float,
    drawer: DrawerState,
    clockHidden: Boolean,
    onClockBounds: (Rect) -> Unit,
    onOpenSettings: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val now by rememberNow()
    val scope = rememberCoroutineScope()
    val view = LocalView.current
    var heightPx by remember { mutableIntStateOf(1) }

    // Launcher tidak boleh keluar saat tombol kembali ditekan.
    BackHandler(enabled = true) { }

    val cols = settings.gridColumns
    val firstRows = firstPageRows(settings)
    val pages = remember(state.home, cols, firstRows) { chunkPages(state.home, cols, firstRows) }
    val pagerState = rememberPagerState(pageCount = { pages.size })
    val drawerOpen by remember { derivedStateOf { drawer.progress.value > 0.02f } }
    val changeIcon = rememberIconPicker(viewModel)

    LaunchedEffect(clockHidden) { if (clockHidden) pagerState.scrollToPage(0) }

    val launchApp: (AppInfo, Rect) -> Unit = { app, r ->
        viewModel.launch(
            app, view,
            r.left.roundToInt(), r.top.roundToInt(), r.width.roundToInt(), r.height.roundToInt()
        )
    }
    val dockApps = remember(state.dock, settings.dockCount) { state.dock.take(settings.dockCount) }
    val a = settings.scrim

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .pinchIn { onOpenSettings() }
            .draggable(
                state = rememberDraggableState { d ->
                    scope.launch { drawer.drag(-d / (heightPx * 0.7f)) }
                },
                orientation = Orientation.Vertical,
                enabled = !clockHidden,
                onDragStopped = { v ->
                    scope.launch {
                        drawer.settle(drawer.progress.value > 0.3f || v < -1200f, settings.animSpeed)
                    }
                }
            )
    ) {
        // Redup wallpaper, muncul bertahap saat lock terbuka.
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = ((progress() - 0.1f) / 0.6f).coerceIn(0f, 1f) }
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = (a * 1.3f).coerceIn(0f, 1f)),
                            Color.Black.copy(alpha = (a * 0.4f).coerceIn(0f, 1f)),
                            Color.Black.copy(alpha = (a * 1.8f).coerceIn(0f, 1f))
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .graphicsLayer {
                    val t = ((progress() - 0.12f) / 0.6f).coerceIn(0f, 1f)
                    val d = drawer.progress.value.coerceIn(0f, 1f)
                    val e = homeEnter().coerceIn(0f, 1f)
                    // Gaya iOS: beranda sedikit mengecil saat drawer terbuka, dan zoom masuk saat kembali.
                    alpha = t * (1f - 0.65f * d) * (0.35f + 0.65f * e)
                    val sc = (0.95f + 0.05f * t) * (1f - 0.08f * d) * (1.10f - 0.10f * e)
                    scaleX = sc
                    scaleY = sc
                }
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) { page ->
                HomePage(
                    page = page,
                    items = pages[page],
                    cols = cols,
                    rows = if (page == 0) firstRows else OTHER_PAGE_ROWS,
                    settings = settings,
                    vm = viewModel,
                    progress = progress,
                    pagerState = pagerState,
                    now = now,
                    clockHidden = clockHidden,
                    onClockBounds = onClockBounds,
                    launchApp = launchApp,
                    changeIcon = changeIcon,
                    onOpenSettings = onOpenSettings
                )
            }

            if (pages.size > 1) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    repeat(pages.size) { i ->
                        val current = i == pagerState.currentPage
                        Box(
                            Modifier
                                .padding(horizontal = 3.dp)
                                .size(if (current) 8.dp else 6.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = if (current) 0.95f else 0.4f))
                        )
                    }
                }
            }

            Dock(
                apps = dockApps,
                vm = viewModel,
                settings = settings,
                launchApp = launchApp,
                changeIcon = changeIcon,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )
        }

        if (drawerOpen) {
            AppDrawer(
                apps = state.apps,
                vm = viewModel,
                settings = settings,
                drawer = drawer,
                launchApp = launchApp,
                onChangeIcon = changeIcon
            )
        }
    }
}

@Composable
private fun HomePage(
    page: Int,
    items: List<AppInfo>,
    cols: Int,
    rows: Int,
    settings: ZeruuSettings,
    vm: HomeViewModel,
    progress: () -> Float,
    pagerState: PagerState,
    now: LocalDateTime,
    clockHidden: Boolean,
    onClockBounds: (Rect) -> Unit,
    launchApp: (AppInfo, Rect) -> Unit,
    changeIcon: (AppInfo) -> Unit,
    onOpenSettings: () -> Unit
) {
    val clockTop = settings.lockY < 0.5f
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                // Efek geser halaman gaya iOS: halaman di samping mengecil dan memudar.
                val off = ((pagerState.currentPage - page) + pagerState.currentPageOffsetFraction)
                    .absoluteValue.coerceAtMost(1f)
                val s = 1f - 0.08f * off
                scaleX = s
                scaleY = s
                alpha = 1f - 0.5f * off
            }
    ) {
        // Area kosong: tahan lama membuka pengaturan Zeruu.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures(onLongPress = { onOpenSettings() }) }
        )
        Column(Modifier.fillMaxSize()) {
            if (page == 0) {
                HomeClockWidget(
                    settings = settings,
                    now = now,
                    hidden = clockHidden,
                    progress = progress,
                    onBounds = { r ->
                        if (pagerState.currentPage == 0 && pagerState.currentPageOffsetFraction == 0f) {
                            onClockBounds(r)
                        }
                    },
                    modifier = Modifier.padding(top = 12.dp)
                )
            }
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp)
            ) {
                for (r in 0 until rows) {
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        for (c in 0 until cols) {
                            val app = items.getOrNull(r * cols + c)
                            Box(
                                Modifier.weight(1f).fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                if (app != null) {
                                    // Ikon masuk berkelompok per baris; arah dan urutan mengikuti posisi jam.
                                    val enter = Modifier.graphicsLayer {
                                        if (!settings.staggerIcons) return@graphicsLayer
                                        val p = progress()
                                        if (p >= 1f) return@graphicsLayer
                                        val order = if (clockTop) min(r, 7) else 7 - min(r, 7)
                                        val raw = ((p - 0.2f - order * 0.045f) / 0.5f).coerceIn(0f, 1f)
                                        val e = easeOutBack(raw, 0.6f + settings.animBounce * 1.6f)
                                        alpha = (raw * 1.8f).coerceIn(0f, 1f)
                                        val sc = 0.55f + 0.45f * e
                                        scaleX = sc
                                        scaleY = sc
                                        val dirY = if (clockTop) 1f else -1f
                                        translationY = dirY * 48.dp.toPx() * (1f - e)
                                        translationX = (0.5f - settings.lockX) * 36.dp.toPx() * (1f - e)
                                    }
                                    AppIconItem(
                                        app = app,
                                        vm = vm,
                                        settings = settings,
                                        showLabel = true,
                                        menu = listOf(
                                            "Hapus dari beranda" to { vm.removeFromHome(app) },
                                            "Ubah ikon" to { changeIcon(app) },
                                            "Reset ikon" to { vm.resetIcon(app) },
                                            "Info aplikasi" to { vm.openInfo(app) },
                                            "Copot pemasangan" to { vm.uninstall(app) }
                                        ),
                                        onOpen = { launchApp(app, it) },
                                        modifier = enter
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Widget jam di beranda (gaya Flux): titik tujuan animasi morph dari lock screen. */
@Composable
private fun HomeClockWidget(
    settings: ZeruuSettings,
    now: LocalDateTime,
    hidden: Boolean,
    progress: () -> Float,
    onBounds: (Rect) -> Unit,
    modifier: Modifier = Modifier
) {
    val align = when (settings.homeClockAlign) {
        1 -> Alignment.CenterHorizontally
        2 -> Alignment.End
        else -> Alignment.Start
    }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()) }
    val dateText: @Composable () -> Unit = {
        if (settings.showDate) {
            Text(
                text = now.format(dateFormatter),
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 16.sp,
                style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.3f), Offset.Zero, 6f)),
                modifier = Modifier.graphicsLayer {
                    alpha = ((progress() - 0.5f) / 0.5f).coerceIn(0f, 1f)
                }
            )
        }
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
        horizontalAlignment = align
    ) {
        if (settings.clockDatePos == 0) dateText()
        Box(
            Modifier
                .onGloballyPositioned { onBounds(it.boundsInRoot()) }
                .graphicsLayer { alpha = if (hidden) 0f else 1f }
        ) {
            LivingClockText(settings, settings.homeClockSize, now)
        }
        if (settings.clockDatePos != 0) dateText()
    }
}

@Composable
private fun Dock(
    apps: List<AppInfo>,
    vm: HomeViewModel,
    settings: ZeruuSettings,
    launchApp: (AppInfo, Rect) -> Unit,
    changeIcon: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!settings.dockEnabled || apps.isEmpty()) return
    val shape = RoundedCornerShape(settings.dockRadius.dp)
    val lv = settings.dockGlassLevel.coerceIn(0f, 1f)
    val look = if (settings.dockGlass) {
        // Liquid glass: isi tembus pandang bergradasi + tepi bercahaya di bagian atas.
        Modifier
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.10f + 0.22f * lv),
                        Color.White.copy(alpha = 0.04f + 0.08f * lv)
                    )
                ),
                shape
            )
            .border(
                1.dp,
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.25f + 0.55f * lv), Color.White.copy(alpha = 0.05f))
                ),
                shape
            )
    } else {
        Modifier.background(Color.White.copy(alpha = settings.dockAlpha), shape)
    }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .then(look)
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        apps.forEach { app ->
            AppIconItem(
                app = app,
                vm = vm,
                settings = settings,
                showLabel = false,
                menu = listOf(
                    "Ubah ikon" to { changeIcon(app) },
                    "Reset ikon" to { vm.resetIcon(app) },
                    "Info aplikasi" to { vm.openInfo(app) }
                ),
                onOpen = { launchApp(app, it) }
            )
        }
    }
}
