package com.zeruu.launcher.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.zeruu.launcher.data.ZeruuSettings
import com.zeruu.launcher.ui.clock.LivingClockText
import com.zeruu.launcher.ui.clock.rememberNow
import com.zeruu.launcher.ui.theme.ZeruuInk
import kotlin.math.roundToInt

private val Swatches = listOf(
    0xFF5CE1E6, 0xFFFFFFFF, 0xFFFF8A65, 0xFFFF6FA5,
    0xFFB388FF, 0xFFA5D6A7, 0xFFFFD54F, 0xFF82B1FF
)

@Composable
fun StylePage(
    settings: ZeruuSettings,
    onChange: ((ZeruuSettings) -> ZeruuSettings) -> Unit,
    onClose: () -> Unit,
    onPreviewLock: () -> Unit,
    onEditLockClock: () -> Unit
) {
    val now by rememberNow()
    val ctx = LocalContext.current
    val version = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
    }
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.97f)
    ) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Gaya (Tema Anda)",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
                Button(onClick = onClose) { Text("Kembali") }
            }

            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Pratinjau langsung
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(settings.accent).copy(alpha = 0.55f), ZeruuInk)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    LivingClockText(
                        settings,
                        (settings.lockClockSize * 0.7f).coerceAtMost(84f),
                        now
                    )
                }

                Section("Tema siap pakai") {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onChange { ZeruuSettings(accent = it.accent, themeMode = it.themeMode) } }) {
                            Text("Zeruu (bawaan)")
                        }
                        Button(onClick = {
                            onChange {
                                it.copy(
                                    clockStyle = 3, clockStacked = false, clockColon = true,
                                    clockGlass = true, clockGlassLevel = 0.7f, clockGlow = true,
                                    lockClockSize = 150f, homeClockSize = 170f, homeClockAlign = 1,
                                    clockDatePos = 0, showDate = true,
                                    dockGlass = true, dockGlassLevel = 0.7f, iconShape = 2
                                )
                            }
                        }) { Text("Flux") }
                    }
                    Text(
                        "Flux: jam besar dan ramping di lock screen dan beranda, liquid glass pada jam dan dock.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Section("Jam Hidup") {
                    ChipRow("Gaya huruf", listOf("Tipis", "Tebal", "Serif", "Ramping"), settings.clockStyle) { i ->
                        onChange { it.copy(clockStyle = i) }
                    }
                    ChipRow("Susunan", listOf("Satu baris", "Bertumpuk"), if (settings.clockStacked) 1 else 0) { i ->
                        onChange { it.copy(clockStacked = i == 1) }
                    }
                    ChipRow("Posisi tanggal", listOf("Di atas jam", "Di bawah jam"), settings.clockDatePos) { i ->
                        onChange { it.copy(clockDatePos = i) }
                    }
                    ChipRow("Format jam", listOf("Ikuti sistem", "12 jam", "24 jam"), settings.clockFormat) { i ->
                        onChange { it.copy(clockFormat = i) }
                    }
                    ColorRow("Warna jam", settings.clockColor) { c -> onChange { it.copy(clockColor = c) } }
                    SwitchRow("Cahaya kontur (glow)", settings.clockGlow) { v -> onChange { it.copy(clockGlow = v) } }
                    SwitchRow("Liquid glass pada jam", settings.clockGlass) { v -> onChange { it.copy(clockGlass = v) } }
                    SliderRow("Tingkat liquid glass jam", settings.clockGlassLevel, 0f..1f, 0, "${(settings.clockGlassLevel * 100).roundToInt()}%") { v ->
                        onChange { it.copy(clockGlassLevel = v) }
                    }
                    SwitchRow("Tanda titik dua", settings.clockColon) { v -> onChange { it.copy(clockColon = v) } }
                    SwitchRow("Tampilkan tanggal", settings.showDate) { v -> onChange { it.copy(showDate = v) } }
                    SliderRow("Ukuran jam lock screen", settings.lockClockSize, 60f..220f, 0, "${settings.lockClockSize.roundToInt()} sp") { v ->
                        onChange { it.copy(lockClockSize = v) }
                    }
                    SliderRow("Ukuran jam home screen", settings.homeClockSize, 36f..260f, 0, "${settings.homeClockSize.roundToInt()} sp") { v ->
                        onChange { it.copy(homeClockSize = v) }
                    }
                    ChipRow("Posisi jam di home", listOf("Kiri", "Tengah", "Kanan"), settings.homeClockAlign) { i ->
                        onChange { it.copy(homeClockAlign = i) }
                    }
                }

                Section("Lock Screen") {
                    Button(onClick = onPreviewLock, modifier = Modifier.fillMaxWidth()) {
                        Text("Pratinjau lock screen dan animasi jam")
                    }
                    OutlinedButton(onClick = onEditLockClock, modifier = Modifier.fillMaxWidth()) {
                        Text("Atur posisi jam di lock screen")
                    }
                    SwitchRow("Tampilkan info baterai", settings.showBattery) { v -> onChange { it.copy(showBattery = v) } }
                    SwitchRow("Animasi jam saat membuka kunci sistem", settings.systemUnlockAnim) { v ->
                        onChange { it.copy(systemUnlockAnim = v) }
                    }
                    Text(
                        "Lock screen sistem Android tidak bisa diganti oleh launcher. Zeruu memutar animasi jam ke home setelah kamu membuka kunci, dan lock screen di atas adalah pratinjau di dalam aplikasi.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Section("Ikon dan Grid") {
                    SliderRow("Kolom grid", settings.gridColumns.toFloat(), 3f..6f, 2, "${settings.gridColumns}") { v ->
                        onChange { it.copy(gridColumns = v.roundToInt()) }
                    }
                    SliderRow("Ukuran ikon", settings.iconSize, 40f..72f, 0, "${settings.iconSize.roundToInt()} dp") { v ->
                        onChange { it.copy(iconSize = v) }
                    }
                    ChipRow("Bentuk ikon", listOf("Asli", "Lingkaran", "Squircle", "Persegi bulat"), settings.iconShape) { i ->
                        onChange { it.copy(iconShape = i) }
                    }
                    SwitchRow("Tampilkan nama aplikasi", settings.showLabels) { v -> onChange { it.copy(showLabels = v) } }
                    SliderRow("Ukuran nama aplikasi", settings.labelSize, 9f..14f, 0, "${settings.labelSize.roundToInt()} sp") { v ->
                        onChange { it.copy(labelSize = v) }
                    }
                }

                Section("Dock") {
                    SwitchRow("Tampilkan dock", settings.dockEnabled) { v -> onChange { it.copy(dockEnabled = v) } }
                    SwitchRow("Dock liquid glass", settings.dockGlass) { v -> onChange { it.copy(dockGlass = v) } }
                    SliderRow("Tingkat liquid glass dock", settings.dockGlassLevel, 0f..1f, 0, "${(settings.dockGlassLevel * 100).roundToInt()}%") { v ->
                        onChange { it.copy(dockGlassLevel = v) }
                    }
                    SliderRow("Jumlah ikon dock", settings.dockCount.toFloat(), 3f..5f, 1, "${settings.dockCount}") { v ->
                        onChange { it.copy(dockCount = v.roundToInt()) }
                    }
                    SliderRow("Transparansi dock (mode biasa)", settings.dockAlpha, 0f..0.6f, 0, "${(settings.dockAlpha * 100).roundToInt()}%") { v ->
                        onChange { it.copy(dockAlpha = v) }
                    }
                    SliderRow("Kelengkungan dock", settings.dockRadius, 0f..44f, 0, "${settings.dockRadius.roundToInt()} dp") { v ->
                        onChange { it.copy(dockRadius = v) }
                    }
                }

                Section("Tema") {
                    ChipRow("Mode", listOf("Ikuti sistem", "Terang", "Gelap"), settings.themeMode) { i ->
                        onChange { it.copy(themeMode = i) }
                    }
                    ColorRow("Warna aksen", settings.accent) { c -> onChange { it.copy(accent = c) } }
                    SliderRow("Redupkan wallpaper", settings.scrim, 0f..0.7f, 0, "${(settings.scrim * 100).roundToInt()}%") { v ->
                        onChange { it.copy(scrim = v) }
                    }
                }

                OutlinedButton(onClick = { onChange { ZeruuSettings() } }, modifier = Modifier.fillMaxWidth()) {
                    Text("Reset semua pengaturan")
                }
                Text("Zeruu Launcher v$version", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    display: String,
    onChange: (Float) -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, modifier = Modifier.weight(1f))
            Text(display, color = MaterialTheme.colorScheme.primary)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun ChipRow(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { i, name ->
                FilterChip(selected = i == selected, onClick = { onSelect(i) }, label = { Text(name) })
            }
        }
    }
}

@Composable
private fun ColorRow(label: String, selected: Long, onSelect: (Long) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Swatches.forEach { c ->
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(
                            width = if (c == selected) 3.dp else 1.dp,
                            color = if (c == selected) MaterialTheme.colorScheme.onSurface else Color.Gray,
                            shape = CircleShape
                        )
                        .clickable { onSelect(c) }
                )
            }
        }
    }
}


@Composable
fun AnimationPage(
    settings: ZeruuSettings,
    onChange: ((ZeruuSettings) -> ZeruuSettings) -> Unit,
    onBack: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.97f)
    ) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Animasi", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                Button(onClick = onBack) { Text("Kembali") }
            }
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Section("Animasi") {
                    SliderRow("Kecepatan animasi", settings.animSpeed, 0.5f..2f, 0, "${"%.1f".format(settings.animSpeed)}x") { v ->
                        onChange { it.copy(animSpeed = v) }
                    }
                    SliderRow("Pantulan", settings.animBounce, 0f..1f, 0, "${(settings.animBounce * 100).roundToInt()}%") { v ->
                        onChange { it.copy(animBounce = v) }
                    }
                    SwitchRow("Ikon masuk berkelompok saat membuka kunci", settings.staggerIcons) { v ->
                        onChange { it.copy(staggerIcons = v) }
                    }
                }

            }
        }
    }
}
