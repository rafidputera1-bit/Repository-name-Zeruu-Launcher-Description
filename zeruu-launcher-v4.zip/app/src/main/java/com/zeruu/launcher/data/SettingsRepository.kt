package com.zeruu.launcher.data

import android.content.Context

class SettingsRepository(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("zeruu_settings", Context.MODE_PRIVATE)

    fun load(): ZeruuSettings {
        val d = ZeruuSettings()
        return ZeruuSettings(
            themeMode = prefs.getInt("themeMode", d.themeMode),
            accent = prefs.getLong("accent", d.accent),
            scrim = prefs.getFloat("scrim", d.scrim),
            clockStyle = prefs.getInt("clockStyle", d.clockStyle),
            clockStacked = prefs.getBoolean("clockStacked", d.clockStacked),
            clockColor = prefs.getLong("clockColor", d.clockColor),
            clockGlow = prefs.getBoolean("clockGlow", d.clockGlow),
            clockColon = prefs.getBoolean("clockColon", d.clockColon),
            clockDatePos = prefs.getInt("clockDatePos", d.clockDatePos),
            clockGlass = prefs.getBoolean("clockGlass", d.clockGlass),
            clockGlassLevel = prefs.getFloat("clockGlassLevel", d.clockGlassLevel),
            clockFormat = prefs.getInt("clockFormat", d.clockFormat),
            showDate = prefs.getBoolean("showDate", d.showDate),
            lockClockSize = prefs.getFloat("lockClockSize", d.lockClockSize),
            homeClockSize = prefs.getFloat("homeClockSize", d.homeClockSize),
            homeClockAlign = prefs.getInt("homeClockAlign", d.homeClockAlign),
            lockX = prefs.getFloat("lockX", d.lockX),
            lockY = prefs.getFloat("lockY", d.lockY),
            showBattery = prefs.getBoolean("showBattery", d.showBattery),
            gridColumns = prefs.getInt("gridColumns", d.gridColumns),
            iconSize = prefs.getFloat("iconSize", d.iconSize),
            iconShape = prefs.getInt("iconShape", d.iconShape),
            showLabels = prefs.getBoolean("showLabels", d.showLabels),
            labelSize = prefs.getFloat("labelSize", d.labelSize),
            dockEnabled = prefs.getBoolean("dockEnabled", d.dockEnabled),
            dockCount = prefs.getInt("dockCount", d.dockCount),
            dockAlpha = prefs.getFloat("dockAlpha", d.dockAlpha),
            dockRadius = prefs.getFloat("dockRadius", d.dockRadius),
            dockGlass = prefs.getBoolean("dockGlass", d.dockGlass),
            dockGlassLevel = prefs.getFloat("dockGlassLevel", d.dockGlassLevel),
            animSpeed = prefs.getFloat("animSpeed", d.animSpeed),
            animBounce = prefs.getFloat("animBounce", d.animBounce),
            staggerIcons = prefs.getBoolean("staggerIcons", d.staggerIcons),
            systemUnlockAnim = prefs.getBoolean("systemUnlockAnim", d.systemUnlockAnim)
        )
    }

    fun save(s: ZeruuSettings) {
        prefs.edit()
            .putInt("themeMode", s.themeMode)
            .putLong("accent", s.accent)
            .putFloat("scrim", s.scrim)
            .putInt("clockStyle", s.clockStyle)
            .putBoolean("clockStacked", s.clockStacked)
            .putLong("clockColor", s.clockColor)
            .putBoolean("clockGlow", s.clockGlow)
            .putBoolean("clockColon", s.clockColon)
            .putInt("clockDatePos", s.clockDatePos)
            .putBoolean("clockGlass", s.clockGlass)
            .putFloat("clockGlassLevel", s.clockGlassLevel)
            .putInt("clockFormat", s.clockFormat)
            .putBoolean("showDate", s.showDate)
            .putFloat("lockClockSize", s.lockClockSize)
            .putFloat("homeClockSize", s.homeClockSize)
            .putInt("homeClockAlign", s.homeClockAlign)
            .putFloat("lockX", s.lockX)
            .putFloat("lockY", s.lockY)
            .putBoolean("showBattery", s.showBattery)
            .putInt("gridColumns", s.gridColumns)
            .putFloat("iconSize", s.iconSize)
            .putInt("iconShape", s.iconShape)
            .putBoolean("showLabels", s.showLabels)
            .putFloat("labelSize", s.labelSize)
            .putBoolean("dockEnabled", s.dockEnabled)
            .putInt("dockCount", s.dockCount)
            .putFloat("dockAlpha", s.dockAlpha)
            .putFloat("dockRadius", s.dockRadius)
            .putBoolean("dockGlass", s.dockGlass)
            .putFloat("dockGlassLevel", s.dockGlassLevel)
            .putFloat("animSpeed", s.animSpeed)
            .putFloat("animBounce", s.animBounce)
            .putBoolean("staggerIcons", s.staggerIcons)
            .putBoolean("systemUnlockAnim", s.systemUnlockAnim)
            .apply()
    }
}
