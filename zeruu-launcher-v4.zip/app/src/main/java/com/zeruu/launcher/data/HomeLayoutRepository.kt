package com.zeruu.launcher.data

import android.content.Context

/** Menyimpan susunan beranda: daftar berurutan (halaman dihitung otomatis), dock, dan aplikasi yang sudah pernah dilihat. */
class HomeLayoutRepository(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("zeruu_layout", Context.MODE_PRIVATE)

    fun hasLayout(): Boolean = prefs.contains("home")

    fun loadHome(): List<String> = decode(prefs.getString("home", "") ?: "")

    fun loadDock(): List<String> = decode(prefs.getString("dock", "") ?: "")

    fun loadSeen(): Set<String> = prefs.getStringSet("seen", emptySet())?.toSet() ?: emptySet()

    fun save(home: List<String>, dock: List<String>, seen: Set<String>) {
        prefs.edit()
            .putString("home", home.joinToString("\n"))
            .putString("dock", dock.joinToString("\n"))
            .putStringSet("seen", seen)
            .apply()
    }

    private fun decode(s: String): List<String> = if (s.isEmpty()) emptyList() else s.split("\n")
}
