package com.zeruu.launcher.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.zeruu.launcher.ui.home.DrawerState
import com.zeruu.launcher.ui.home.HomeScreen
import com.zeruu.launcher.ui.home.HomeViewModel
import com.zeruu.launcher.ui.lock.LockLayer
import com.zeruu.launcher.ui.lock.UnlockState
import com.zeruu.launcher.ui.settings.SettingsHost
import com.zeruu.launcher.ui.settings.SettingsViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ZeruuRoot(
    homeViewModel: HomeViewModel,
    settingsViewModel: SettingsViewModel,
    unlockSignal: Int,
    resumeSignal: Int
) {
    val settings by settingsViewModel.settings.collectAsState()
    val scope = rememberCoroutineScope()
    val unlock = remember { UnlockState() }
    val drawer = remember { DrawerState() }
    val homeEnter = remember { Animatable(1f) }
    var showSettings by remember { mutableStateOf(false) }
    var systemMode by remember { mutableStateOf(false) }

    // Setelah pengguna membuka kunci sistem: jam muncul besar di posisi lock lalu mengalir ke widget jam beranda.
    LaunchedEffect(unlockSignal) {
        if (unlockSignal > 0 && settings.systemUnlockAnim && !showSettings) {
            systemMode = true
            unlock.showLock()
            delay(140)
            unlock.animateTo(1f, settings.animSpeed, settings.animBounce)
            systemMode = false
        }
    }

    // Kembali ke beranda dari aplikasi lain: drawer menutup, beranda zoom masuk (gaya iOS).
    LaunchedEffect(resumeSignal) {
        if (resumeSignal > 0) {
            drawer.progress.snapTo(0f)
            if (!unlock.lockVisible) {
                homeEnter.snapTo(0f)
                homeEnter.animateTo(
                    1f,
                    spring(dampingRatio = 0.8f, stiffness = 300f * settings.animSpeed.coerceIn(0.4f, 2.5f))
                )
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(
            viewModel = homeViewModel,
            settings = settings,
            progress = { unlock.progress.value },
            homeEnter = { homeEnter.value },
            drawer = drawer,
            clockHidden = unlock.lockVisible,
            onClockBounds = { unlock.homeClockBounds = it },
            onOpenSettings = { showSettings = true }
        )

        if (unlock.lockVisible) {
            LockLayer(
                settings = settings,
                unlock = unlock,
                systemMode = systemMode,
                onMoveCommit = { x, y -> settingsViewModel.update { it.copy(lockX = x, lockY = y) } }
            )
        }

        val ms = (320 / settings.animSpeed).toInt()
        AnimatedVisibility(
            visible = showSettings,
            enter = slideInVertically(tween(ms)) { it / 6 } + fadeIn(tween(ms)),
            exit = slideOutVertically(tween(ms)) { it / 6 } + fadeOut(tween(ms))
        ) {
            SettingsHost(
                settings = settings,
                onChange = { settingsViewModel.update(it) },
                onClose = { showSettings = false },
                onPreviewLock = {
                    showSettings = false
                    scope.launch { delay(280); unlock.showLock() }
                },
                onEditLockClock = {
                    showSettings = false
                    scope.launch { delay(280); unlock.showLock(); unlock.editMode = true }
                }
            )
        }
    }
}
