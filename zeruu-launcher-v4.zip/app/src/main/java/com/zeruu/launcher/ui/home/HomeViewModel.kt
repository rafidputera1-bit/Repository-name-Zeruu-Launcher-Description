package com.zeruu.launcher.ui.home

import android.app.Application
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.net.Uri
import android.os.UserHandle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zeruu.launcher.data.AppInfo
import com.zeruu.launcher.data.AppRepository
import com.zeruu.launcher.data.HomeLayoutRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeUiState(
    val apps: List<AppInfo> = emptyList(),   // semua aplikasi (isi app drawer)
    val home: List<AppInfo> = emptyList(),   // isi beranda berurutan
    val dock: List<AppInfo> = emptyList(),
    val loaded: Boolean = false
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val layoutRepo = HomeLayoutRepository(application)

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    /** Naik setiap ikon kustom berubah, supaya ikon yang tampil dimuat ulang. */
    private val _iconVersion = MutableStateFlow(0)
    val iconVersion: StateFlow<Int> = _iconVersion.asStateFlow()

    private var allApps: List<AppInfo> = emptyList()
    private var homeKeys: List<String> = emptyList()
    private var dockKeys: List<String> = emptyList()
    private var seenKeys: Set<String> = emptySet()
    private var loadJob: Job? = null

    private val packageCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String, user: UserHandle) = refresh()
        override fun onPackageAdded(packageName: String, user: UserHandle) = refresh()
        override fun onPackageChanged(packageName: String, user: UserHandle) = refresh(packageName)
        override fun onPackagesAvailable(
            packageNames: Array<out String>, user: UserHandle, replacing: Boolean
        ) = refresh()

        override fun onPackagesUnavailable(
            packageNames: Array<out String>, user: UserHandle, replacing: Boolean
        ) = refresh()
    }

    init {
        repository.registerCallback(packageCallback)
        refresh()
    }

    fun refresh(changedPackage: String? = null) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            if (changedPackage != null) repository.invalidateIcons(changedPackage)
            val apps = repository.loadApps()
            allApps = apps
            val keys = apps.map { it.key }.toSet()
            if (!layoutRepo.hasLayout()) {
                val (home, dock) = defaultLayout(apps)
                homeKeys = home
                dockKeys = dock
                seenKeys = keys
            } else {
                seenKeys = layoutRepo.loadSeen().filter { it in keys }.toSet()
                homeKeys = layoutRepo.loadHome().filter { it in keys }
                dockKeys = layoutRepo.loadDock().filter { it in keys }
                val fresh = apps.map { it.key }.filter { it !in seenKeys }
                if (fresh.isNotEmpty()) {
                    homeKeys = homeKeys + fresh
                    seenKeys = seenKeys + fresh
                }
            }
            layoutRepo.save(homeKeys, dockKeys, seenKeys)
            publish()
        }
    }

    private fun publish() {
        val byKey = allApps.associateBy { it.key }
        _state.value = HomeUiState(
            apps = allApps,
            home = homeKeys.mapNotNull { byKey[it] },
            dock = dockKeys.mapNotNull { byKey[it] },
            loaded = true
        )
    }

    // ----- Aksi pengguna -----
    fun addToHome(app: AppInfo) {
        if (app.key in homeKeys) {
            repository.toast("Sudah ada di beranda")
            return
        }
        homeKeys = homeKeys + app.key
        layoutRepo.save(homeKeys, dockKeys, seenKeys)
        publish()
        repository.toast("Ditambahkan ke beranda")
    }

    fun removeFromHome(app: AppInfo) {
        homeKeys = homeKeys - app.key
        layoutRepo.save(homeKeys, dockKeys, seenKeys)
        publish()
    }

    fun launch(app: AppInfo, view: View?, left: Int, top: Int, width: Int, height: Int) =
        repository.launch(app, view, left, top, width, height)

    fun openInfo(app: AppInfo) = repository.openAppInfo(app.packageName)

    fun uninstall(app: AppInfo) = repository.uninstall(app.packageName)

    // ----- Ikon -----
    fun cachedIcon(app: AppInfo): ImageBitmap? = repository.cachedIcon(app.key)

    suspend fun loadIcon(app: AppInfo): ImageBitmap? = repository.loadIcon(app)

    fun setCustomIcon(app: AppInfo, uri: Uri) {
        viewModelScope.launch {
            if (repository.setCustomIcon(app, uri)) {
                _iconVersion.update { it + 1 }
            } else {
                repository.toast("Gambar tidak dapat dipakai")
            }
        }
    }

    fun resetIcon(app: AppInfo) {
        repository.resetCustomIcon(app)
        _iconVersion.update { it + 1 }
        refresh(app.packageName)
    }

    // ----- Susunan awal -----
    /** Dock: telepon, pesan, browser, kamera. Beranda: aplikasi umum; sisanya hanya di app drawer. */
    private fun defaultLayout(apps: List<AppInfo>): Pair<List<String>, List<String>> {
        val pm = getApplication<Application>().packageManager
        fun pkgOf(intent: Intent): String? =
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName?.takeIf { it != "android" }

        val dockPkgs = listOfNotNull(
            pkgOf(Intent(Intent.ACTION_DIAL)),
            pkgOf(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))),
            pkgOf(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))),
            pkgOf(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        ).distinct()

        val categories = listOf(
            Intent.CATEGORY_APP_GALLERY, Intent.CATEGORY_APP_MARKET, Intent.CATEGORY_APP_CALENDAR,
            Intent.CATEGORY_APP_CALCULATOR, Intent.CATEGORY_APP_CONTACTS, Intent.CATEGORY_APP_MAPS,
            Intent.CATEGORY_APP_MUSIC, Intent.CATEGORY_APP_EMAIL
        )
        val homePkgs = (categories.mapNotNull { pkgOf(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, it)) } +
            listOfNotNull(pkgOf(Intent(Settings.ACTION_SETTINGS))))
            .distinct()
            .filter { it !in dockPkgs }

        fun keyOf(pkg: String): String? = apps.firstOrNull { it.packageName == pkg }?.key

        var dock = dockPkgs.mapNotNull { keyOf(it) }
        var home = homePkgs.mapNotNull { keyOf(it) }
        if (dock.isEmpty()) dock = apps.take(4).map { it.key }
        if (home.size < 8) {
            val used = (dock + home).toSet()
            home = home + apps.map { it.key }.filter { it !in used }.take(8 - home.size)
        }
        return home to dock
    }

    override fun onCleared() {
        repository.unregisterCallback(packageCallback)
        super.onCleared()
    }
}
