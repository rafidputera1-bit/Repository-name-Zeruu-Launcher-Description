package com.zeruu.launcher.ui.home

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeruu.launcher.data.AppInfo
import com.zeruu.launcher.data.ZeruuSettings

internal fun iconShapeOf(settings: ZeruuSettings): Shape? = when (settings.iconShape) {
    1 -> CircleShape
    2 -> RoundedCornerShape(percent = 30)
    3 -> RoundedCornerShape(percent = 18)
    else -> null
}

@Composable
fun AppIconImage(app: AppInfo, vm: HomeViewModel, settings: ZeruuSettings) {
    val version by vm.iconVersion.collectAsState()
    val icon by produceState<ImageBitmap?>(initialValue = vm.cachedIcon(app), app.key, version) {
        value = vm.loadIcon(app) ?: value
    }
    val shape = iconShapeOf(settings)
    val size = Modifier
        .size(settings.iconSize.dp)
        .then(if (shape != null) Modifier.clip(shape) else Modifier)
    val bmp = icon
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = app.label, modifier = size)
    } else {
        // Penampung sementara sampai ikon selesai dimuat (tidak memblokir tampilan).
        Box(size.background(Color.White.copy(alpha = 0.14f), shape ?: RoundedCornerShape(percent = 24)))
    }
}

/**
 * Ikon aplikasi. Ketuk membuka dengan animasi zoom, tahan lama menampilkan menu.
 * [menu] berisi pasangan (judul, aksi).
 */
@Composable
fun AppIconItem(
    app: AppInfo,
    vm: HomeViewModel,
    settings: ZeruuSettings,
    showLabel: Boolean,
    menu: List<Pair<String, () -> Unit>>,
    onOpen: (Rect) -> Unit,
    modifier: Modifier = Modifier
) {
    var pressed by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val currentOnOpen by rememberUpdatedState(onOpen)
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium * settings.animSpeed
        ),
        label = "iconPress"
    )

    Box(modifier) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .onGloballyPositioned { bounds = it.boundsInRoot() }
                .pointerInput(app.key) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onTap = { currentOnOpen(bounds) },
                        onLongPress = { menuOpen = true }
                    )
                }
        ) {
            AppIconImage(app, vm, settings)
            if (showLabel && settings.showLabels) {
                Text(
                    text = app.label,
                    color = Color.White,
                    fontSize = settings.labelSize.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .padding(horizontal = 4.dp)
                )
            }
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            menu.forEach { (title, action) ->
                DropdownMenuItem(
                    text = { Text(title) },
                    onClick = {
                        menuOpen = false
                        action()
                    }
                )
            }
        }
    }
}
