package com.zeruu.launcher.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zeruu.launcher.notif.NotifItem
import com.zeruu.launcher.ui.glass.glassPanel

/** Notifikasi terbaru di beranda, dalam kartu liquid glass. Ketuk untuk membuka notifikasinya. */
@Composable
fun NotificationStack(items: List<NotifItem>, modifier: Modifier = Modifier) {
    if (items.isEmpty()) return
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .fillMaxWidth()
            .background(Color(0x55000000), shape)
            .glassPanel(shape, 0.7f)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            if (items.size == 1) "1 notifikasi" else "${items.size} notifikasi",
            color = Color.White.copy(alpha = 0.65f),
            fontSize = 11.sp
        )
        items.take(2).forEach { n ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .clickable { runCatching { n.intent?.send() } }
            ) {
                Text(
                    n.app + if (n.title.isNotBlank()) "  -  ${n.title}" else "",
                    color = Color.White,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (n.text.isNotBlank()) {
                    Text(
                        n.text,
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
