package com.zeruu.launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.zeruu.launcher.data.ZeruuSettings

val ZeruuAccent = Color(0xFF5CE1E6)
val ZeruuInk = Color(0xFF0B1020)
val ZeruuAmber = Color(0xFFC9A24B)

@Composable
fun ZeruuTheme(settings: ZeruuSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val accent = Color(settings.accent)
    val scheme = if (dark) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color.Black,
            background = Color.Black,
            onBackground = Color.White,
            surface = Color(0xFF1C1C1E),
            onSurface = Color.White,
            secondaryContainer = accent.copy(alpha = 0.30f),
            onSecondaryContainer = Color.White
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = Color.Black,
            background = Color(0xFFF4F7FA),
            onBackground = ZeruuInk,
            surface = Color.White,
            onSurface = ZeruuInk,
            secondaryContainer = accent.copy(alpha = 0.35f),
            onSecondaryContainer = ZeruuInk
        )
    }
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(medium = RoundedCornerShape(28.dp), small = RoundedCornerShape(16.dp)),
        content = content
    )
}

/** True jika blur Gaussian latar belakang aktif; halaman pengaturan lalu dibuat lebih tembus pandang. */
val LocalBlurOn = compositionLocalOf { false }
