package com.zeruu.launcher.notif

import android.app.Notification
import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow

data class NotifItem(
    val key: String,
    val app: String,
    val title: String,
    val text: String,
    val intent: PendingIntent?
)

/**
 * Membaca notifikasi yang sedang aktif agar bisa tampil di beranda.
 * Hanya jalan jika pengguna memberi "akses notifikasi" ke Zeruu di pengaturan sistem.
 */
class ZeruuNotificationService : NotificationListenerService() {

    override fun onListenerConnected() = refresh()

    override fun onListenerDisconnected() {
        items.value = emptyList()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) = refresh()

    override fun onNotificationRemoved(sbn: StatusBarNotification) = refresh()

    private fun refresh() {
        val pm = packageManager
        val list = runCatching { activeNotifications?.toList() ?: emptyList() }.getOrDefault(emptyList())
            .filter {
                it.packageName != packageName && !it.isOngoing &&
                    (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0
            }
            .sortedByDescending { it.postTime }
            .take(6)
            .map { sbn ->
                val extras = sbn.notification.extras
                val app = runCatching {
                    pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
                }.getOrDefault(sbn.packageName)
                NotifItem(
                    key = sbn.key,
                    app = app,
                    title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty(),
                    text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty(),
                    intent = sbn.notification.contentIntent
                )
            }
        items.value = list
    }

    companion object {
        val items = MutableStateFlow<List<NotifItem>>(emptyList())
    }
}
