package com.zeruu.launcher.data

/** Semua pengaturan Zeruu. Setiap field terhubung langsung ke tampilan launcher. */
data class ZeruuSettings(
    // Tema
    val themeMode: Int = 0,            // 0 sistem, 1 terang, 2 gelap
    val accent: Long = 0xFF5CE1E6,
    val scrim: Float = 0.25f,          // redup wallpaper
    // Jam hidup
    val clockStyle: Int = 0,           // 0 tipis, 1 tebal, 2 serif
    val clockStacked: Boolean = false,
    val clockColor: Long = 0xFFFFFFFF,
    val clockGlow: Boolean = true,
    val clockColon: Boolean = true,
    val clockDatePos: Int = 0,         // 0 tanggal di atas jam, 1 di bawah
    val clockGlass: Boolean = true,    // liquid glass pada jam
    val clockGlassLevel: Float = 0.6f,
    val clockFormat: Int = 0,          // 0 sistem, 1 12 jam, 2 24 jam
    val showDate: Boolean = true,
    val lockClockSize: Float = 104f,
    val homeClockSize: Float = 56f,
    val homeClockAlign: Int = 0,       // 0 kiri, 1 tengah, 2 kanan
    val lockX: Float = 0.5f,           // posisi jam lock screen (0..1 dari ruang bebas)
    val lockY: Float = 0.2f,
    val showBattery: Boolean = true,
    // Ikon dan grid
    val gridColumns: Int = 4,
    val iconSize: Float = 56f,
    val iconShape: Int = 0,            // 0 asli, 1 lingkaran, 2 squircle, 3 persegi bulat
    val showLabels: Boolean = true,
    val labelSize: Float = 11f,
    // Dock
    val dockEnabled: Boolean = true,
    val dockCount: Int = 4,
    val dockAlpha: Float = 0.18f,
    val dockRadius: Float = 32f,
    val dockGlass: Boolean = true,
    val dockGlassLevel: Float = 0.6f,
    // Animasi
    val animSpeed: Float = 1f,
    val animBounce: Float = 0.5f,
    val staggerIcons: Boolean = true,
    val systemUnlockAnim: Boolean = true,
    // Beranda
    val homePages: Int = 3,
    val iconTheme: Int = 0,            // 0 asli, 1 liquid glass, 2 gelap, 3 terang, 4 monokrom
    // Blur Gaussian (latar belakang jendela, Android 12+)
    val blurEnabled: Boolean = true,
    val blurLevel: Float = 0.6f,
    // Lock screen: seni teks dan widget
    val lockWordArt: Boolean = false,
    val lockWordText: String = "Zeruu",
    val lockWidgets: Int = 3,          // bit: 1 baterai, 2 penyimpanan, 4 RAM, 8 tanggal, 16 catatan
    val lockNote: String = "",
    // Tentang perangkat
    val aboutBg: Int = 0,              // 0..5 gradien, 6 gambar sendiri
    val aboutBgStamp: Long = 0L,
    // v0.6: ketuk dua kali, AOD, widget jam, font sendiri
    val lockDoubleTap: Int = 0,        // 0 matikan layar (izin admin), 1 AOD Zeruu
    val aodTimeout: Int = 1,           // indeks: 0 = 5 mnt, 1 = 15 mnt, 2 = 30 mnt, 3 = tanpa batas
    val aodShowDate: Boolean = true,
    val aodShowBattery: Boolean = true,
    val homeDoubleTap: Boolean = true,
    val showHomeClock: Boolean = true,
    val clockFontStamp: Long = 0L,
    // v0.7: jam bisa dipanjangkan, notifikasi di beranda
    val clockScaleX: Float = 1f,
    val clockScaleY: Float = 1f,
    val homeNotifs: Boolean = true,
    // v0.7: keamanan tampilan lock Zeruu + sensor sidik jari bergerak
    val lockMethod: Int = 0,           // 0 geser, 1 pola, 2 PIN, 3 sandi
    val lockSalt: String = "",
    val lockHash: String = "",
    val fpShow: Boolean = true,
    val fpStyle: Int = 0,              // 0 garis, 1 cincin, 2 titik
    val fpColor: Long = 0xFF5CE1E6,
    val fpSize: Float = 72f
)
