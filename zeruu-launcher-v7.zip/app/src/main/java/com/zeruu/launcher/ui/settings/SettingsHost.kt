package com.zeruu.launcher.ui.settings

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.zeruu.launcher.data.ZeruuSettings
import com.zeruu.launcher.ui.theme.LocalBlurOn

private data class SearchItem(
    val title: String,
    val subtitle: String,
    val route: String,
    val icon: ImageVector,
    val keys: String
)

private val SearchItems = listOf(
    SearchItem("Your Theme", "Kustom lock screen dan beranda", "theme", Icons.Filled.Favorite, "tema theme flux preset"),
    SearchItem("Kustom lock screen", "Jam, font, widget, AOD, ketuk dua kali", "lock", Icons.Filled.Lock,
        "jam font huruf widget aod kunci layar liquid glass warna ketuk dua kali lebar tinggi"),
    SearchItem("Kustom beranda", "Halaman, ikon, dock, widget, notifikasi", "homecfg", Icons.Filled.Home,
        "ikon grid halaman dock widget notifikasi blur folder tema ikon bentuk"),
    SearchItem("Animasi", "Kecepatan dan pantulan", "anim", Icons.Filled.PlayArrow, "animasi kecepatan pantulan gerakan"),
    SearchItem("Tentang perangkat", Build.MODEL, "about", Icons.Filled.Info, "perangkat ram penyimpanan versi latar zeruu")
)

/**
 * Setelan Zeruu. Halaman utama berupa kartu bersudut besar dengan ikon emas (gaya pengaturan ColorOS),
 * Your Theme berdiri sendiri. Terbuka dengan mencubit beranda, atau lewat mode edit beranda.
 */
@Composable
fun SettingsHost(
    settings: ZeruuSettings,
    onChange: ((ZeruuSettings) -> ZeruuSettings) -> Unit,
    onClose: () -> Unit,
    onPreviewLock: () -> Unit,
    onEditLockClock: () -> Unit,
    onPreviewAod: () -> Unit,
    onAddWidget: () -> Unit,
    initialRoute: String = "home"
) {
    var route by remember(initialRoute) { mutableStateOf(initialRoute) }
    BackHandler(enabled = true) {
        when (route) {
            "lock", "homecfg" -> route = "theme"
            "theme", "anim", "about" -> route = "home"
            else -> onClose()
        }
    }

    Crossfade(targetState = route, label = "settingsRoute") { r ->
        when (r) {
            "theme" -> YourThemePage(
                settings = settings,
                onChange = onChange,
                onBack = { route = "home" },
                onOpenLock = { route = "lock" },
                onOpenHome = { route = "homecfg" }
            )
            "lock" -> LockStylePage(
                settings = settings,
                onChange = onChange,
                onBack = { route = "theme" },
                onPreviewLock = onPreviewLock,
                onEditLockClock = onEditLockClock,
                onPreviewAod = onPreviewAod
            )
            "homecfg" -> HomeStylePage(
                settings = settings,
                onChange = onChange,
                onBack = { route = "theme" },
                onAddWidget = onAddWidget
            )
            "anim" -> AnimationPage(settings = settings, onChange = onChange, onBack = { route = "home" })
            "about" -> AboutScreen(settings = settings, onChange = onChange, onBack = { route = "home" })
            else -> SettingsHome(onOpen = { route = it }, onClose = onClose)
        }
    }
}

@Composable
private fun SettingsHome(onOpen: (String) -> Unit, onClose: () -> Unit) {
    val blur = LocalBlurOn.current
    var query by remember { mutableStateOf("") }
    val results = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) emptyList() else SearchItems.filter { (it.title + " " + it.subtitle + " " + it.keys).lowercase().contains(q) }
    }
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background.copy(alpha = if (blur) 0.72f else 0.97f),
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface)
                        .clickable(onClick = onClose),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Tutup") }
                Spacer(Modifier.width(14.dp))
                Text("Setelan Zeruu", style = MaterialTheme.typography.headlineMedium)
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Cari") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                shape = RoundedCornerShape(50),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (query.isNotBlank()) {
                    if (results.isEmpty()) {
                        Text("Tidak ada hasil.", modifier = Modifier.padding(8.dp))
                    } else {
                        Card(colors = cardColors()) {
                            Column {
                                results.forEachIndexed { i, item ->
                                    if (i > 0) HorizontalDivider(Modifier.padding(start = 64.dp))
                                    NavRow(item.icon, item.title, item.subtitle) { onOpen(item.route) }
                                }
                            }
                        }
                    }
                } else {
                    // Your Theme berdiri sendiri, terpisah dari menu lain.
                    Card(colors = cardColors()) {
                        NavRow(Icons.Filled.Favorite, "Your Theme", "Kustom lock screen dan kustom beranda") { onOpen("theme") }
                    }
                    Card(colors = cardColors()) {
                        Column {
                            NavRow(Icons.Filled.PlayArrow, "Animasi", "Kecepatan dan pantulan") { onOpen("anim") }
                            HorizontalDivider(Modifier.padding(start = 64.dp))
                            NavRow(Icons.Filled.Info, "Tentang perangkat", Build.MODEL) { onOpen("about") }
                        }
                    }
                }
            }
        }
    }
}
